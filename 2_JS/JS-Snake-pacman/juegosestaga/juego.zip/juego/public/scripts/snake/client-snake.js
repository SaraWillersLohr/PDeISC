// Controlador del Cliente de Cable Rush (Snake) - Soporta Local (1P/2P) y Online (Sockets)
document.addEventListener('DOMContentLoaded', () => {
  initClient();
});

let canvas, ctx;
let socketConn = null;
let gameConfig = null;
let localGameInstance = null;
let localIntervalId = null;
let lastState = null;

// Controladores táctiles
let touchStartX = 0;
let touchStartY = 0;

function initClient() {
  canvas = document.getElementById('gameCanvas');
  ctx = canvas.getContext('2d');

  // Ajustar tamaño
  resizeCanvas();
  window.addEventListener('resize', resizeCanvas);

  // Leer configuración de sesión
  const configStr = sessionStorage.getItem('gameConfig');
  if (!configStr) {
    window.location.href = '/';
    return;
  }
  gameConfig = JSON.parse(configStr);

  // Inicializar HUD de nombres
  document.getElementById('hudP1Name').textContent = `${gameConfig.p1Name} (${gameConfig.p1Character}): `;
  if (gameConfig.mode === '2P') {
    document.getElementById('hudP2Container').style.display = 'block';
    document.getElementById('p2ControlInfo').style.display = 'inline';
    
    if (gameConfig.multiplayer === 'local') {
      // P2 usa el siguiente cable en la lista: USB->HDMI->Ethernet->USB
      const p2Char = gameConfig.p1Character === 'USB' ? 'HDMI'
                   : gameConfig.p1Character === 'HDMI' ? 'Ethernet'
                   : 'USB';
      document.getElementById('hudP2Name').textContent = `Jugador 2 (${p2Char}): `;
    } else {
      // En online buscamos al rival
      const rival = gameConfig.players.find(p => p.playerIndex !== gameConfig.myIndex);
      if (rival) {
        document.getElementById('hudP2Name').textContent = `${rival.name} (${rival.character}): `;
      }
      document.getElementById('hudRoomInfo').style.display = 'block';
      document.getElementById('hudRoomCode').textContent = gameConfig.roomCode;
    }
  }

  // Bind inputs
  setupKeyboardInput();
  setupTouchInput();

  if (gameConfig.multiplayer === 'online') {
    // --- MODO MULTIJUGADOR ONLINE ---
    socketConn = io();
    
    // Reconectarse a la sala
    socketConn.emit('joinRoom', {
      code: gameConfig.roomCode,
      name: gameConfig.players[gameConfig.myIndex].name,
      character: gameConfig.players[gameConfig.myIndex].character
    });

    socketConn.on('gameState', (state) => {
      handleStateUpdate(state);
    });

    socketConn.on('gameOver', ({ gameState }) => {
      handleStateUpdate(gameState);
    });

    // Acción de modal online
    document.getElementById('btnOverlayAction').textContent = 'Volver al Lobby';
    document.getElementById('btnOverlayAction').onclick = () => {
      window.location.href = '/lobby';
    };
  } else {
    // --- MODO LOCAL (OFFLINE) ---
    setupLocalGame();
  }
}

function resizeCanvas() {
  if (!canvas) return;
  const sizeW = Math.min(window.innerWidth - 40, 600);
  const sizeH = sizeW * (2 / 3); // Relación de aspecto 30x20
  canvas.width = sizeW;
  canvas.height = sizeH;
  if (lastState) {
    drawSnakeGame(canvas, ctx, lastState);
  }
}

// Configurar juego local
function setupLocalGame() {
  const playersList = [
    { socketId: 'local_p1', name: gameConfig.p1Name, character: gameConfig.p1Character, playerIndex: 0 }
  ];

  if (gameConfig.mode === '2P') {
    const p2Char = gameConfig.p1Character === 'USB' ? 'HDMI'
                 : gameConfig.p1Character === 'HDMI' ? 'Ethernet'
                 : 'USB';
    playersList.push({
      socketId: 'local_p2',
      name: 'Jugador 2',
      character: p2Char,
      playerIndex: 1
    });
  }

  localGameInstance = new LocalSnakeEngine(playersList);

  // Arrancar música de fondo
  if (window.audioSynth) {
    window.audioSynth.startBGM('normal');
  }

  // Loop local de Snake — velocidad inicial 100ms (nivel 1)
  let currentInterval = 100;
  let lastLevel = 1;

  const startLoop = (intervalMs) => {
    if (localIntervalId) clearInterval(localIntervalId);
    localIntervalId = setInterval(() => {
      localGameInstance.tick();
      const state = localGameInstance.getSerializedState();

      // Detectar cambio de nivel
      if (state.level !== undefined && state.level !== lastLevel) {
        lastLevel = state.level;
        if (state.level >= 3) {
          window.audioSynth && window.audioSynth.playDangerAlert();
          window.audioSynth && window.audioSynth.switchBGM('danger');
          // Reiniciar loop con velocidad nivel 3+ (MUCHO más rápido)
          const newMs = Math.max(28, 100 - (state.level * 18));
          if (newMs !== currentInterval) {
            currentInterval = newMs;
            startLoop(currentInterval);
          }
        } else {
          window.audioSynth && window.audioSynth.playLevelUp();
        }
      }

      handleStateUpdate(state);

      if (state.state === 'game_over') {
        clearInterval(localIntervalId);
        window.audioSynth && window.audioSynth.stopBGM();
        saveLocalScore(state);
      }
    }, intervalMs);
  };

  startLoop(currentInterval);

  // Configurar acción modal
  const actionBtn = document.getElementById('btnOverlayAction');
  actionBtn.textContent = 'Volver a Jugar';
  actionBtn.onclick = () => {
    clearInterval(localIntervalId);
    document.getElementById('gameOverlay').classList.remove('active');
    setupLocalGame();
  };
}

// Guarda la puntuación de la partida local
async function saveLocalScore(state) {
  try {
    // Guardar puntajes en el backend para ambos jugadores locales
    for (const p of state.players) {
      // Determinar si es ganador
      const isWinner = state.winner === p.socketId || state.winner === 'draw';
      await fetch('/api/leaderboard/snake', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: p.name,
          score: p.score,
          character: p.character,
          duration: state.duration,
          victories: isWinner ? 1 : 0
        })
      });
    }
  } catch (err) {
    console.error('Error al guardar puntaje local:', err);
  }
}

// Procesa el gameState recibido y actualiza HUD y Canvas
function handleStateUpdate(state) {
  // Disparar efectos de audio
  if (lastState) {
    // 1. Sonido al comer item (Datos, Energía o Nodo)
    const currentItemsCount = state.players.reduce((sum, p) => sum + p.segments.length, 0);
    const lastItemsCount = lastState.players.reduce((sum, p) => sum + p.segments.length, 0);
    if (currentItemsCount > lastItemsCount) {
      window.audioSynth.playCoin();
    }

    // 2. Chocar / Morir
    const deadCountNow = state.players.filter(p => p.isDead).length;
    const deadCountLast = lastState.players.filter(p => p.isDead).length;
    if (deadCountNow > deadCountLast) {
      window.audioSynth.playCrash();
    }

    // 3. Audio de Power-ups (si se activa un estado)
    const myIdx = gameConfig.multiplayer === 'online' ? gameConfig.myIndex : 0;
    const meLast = lastState.players.find(p => p.playerIndex === myIdx);
    const meNow = state.players.find(p => p.playerIndex === myIdx);
    if (meLast && meNow) {
      const gotOverclock = meNow.overclock && !meLast.overclock;
      const gotFirewall = meNow.firewall && !meLast.firewall;
      const gotGhost = meNow.ghost && !meLast.ghost;
      const gotEMP = meNow.emp && !meLast.emp;

      if (gotOverclock || gotFirewall || gotGhost || gotEMP) {
        window.audioSynth.playPowerup();
      }
    }
  }

  lastState = state;

  // Actualizar HUD general
  document.getElementById('hudDuration').textContent = `${state.duration}s`;
  
  const p1 = state.players.find(p => p.playerIndex === 0);
  if (p1) {
    document.getElementById('hudP1Score').textContent = p1.score;
  }

  const p2 = state.players.find(p => p.playerIndex === 1);
  if (p2) {
    document.getElementById('hudP2Score').textContent = p2.score;
  }

  // Actualizar indicadores de Powerups del jugador local
  const myIndex = gameConfig.multiplayer === 'online' ? gameConfig.myIndex : 0;
  const me = state.players.find(p => p.playerIndex === myIndex);
  const puContainer = document.getElementById('powerupIndicators');
  if (puContainer && me) {
    puContainer.innerHTML = '';
    if (me.overclock) puContainer.innerHTML += `<span class="powerup-badge badge-overclock">⚡ OVERCLOCK</span>`;
    if (me.firewall) puContainer.innerHTML += `<span class="powerup-badge badge-firewall">🛡️ FIREWALL</span>`;
    if (me.ghost) puContainer.innerHTML += `<span class="powerup-badge badge-ghost">👻 GHOST</span>`;
    if (me.emp) puContainer.innerHTML += `<span class="powerup-badge badge-emp">❄️ FROZEN</span>`;
  }

  // Redibujar
  drawSnakeGame(canvas, ctx, state);

  // Mostrar modal de fin de juego
  const overlay = document.getElementById('gameOverlay');
  const title = document.getElementById('overlayTitle');
  const msg = document.getElementById('overlayMessage');
  const scoreSec = document.getElementById('overlayScoreSection');

  if (state.state === 'game_over') {
    overlay.classList.add('active');
    
    // Obtener los nombres de los jugadores
    const name1 = p1 ? p1.name : 'J1';
    const name2 = p2 ? p2.name : 'J2';

    // Determinar ganador
    let winnerText = '';
    if (state.winner === 'draw') {
      winnerText = '¡Empate Técnico!';
      title.className = 'display-5 text-warning animate-pulse';
    } else {
      const winnerPlayer = state.players.find(p => p.socketId === state.winner);
      if (winnerPlayer) {
        winnerText = `¡Ganador: ${winnerPlayer.name}!`;
        title.className = 'display-5 text-success animate-pulse';
      } else {
        winnerText = 'Partida Finalizada';
        title.className = 'display-5 text-info animate-pulse';
      }
    }

    title.textContent = winnerText;
    msg.textContent = `La partida duró ${state.duration} segundos en el laberinto.`;
    
    // Listado de scores
    scoreSec.innerHTML = `
      <div class="text-info">${name1}: <span class="text-success">${p1 ? p1.score : 0} pts</span></div>
      ${p2 ? `<div class="text-danger">${name2}: <span class="text-success">${p2.score} pts</span></div>` : ''}
    `;
    window.audioSynth.playGameOver();
  }
}

// Bindeo de Controles de Teclado
function setupKeyboardInput() {
  window.addEventListener('keydown', (e) => {
    const key = e.key.toUpperCase();
    
    // Player 1: WASD
    let p1Dir = null;
    if (key === 'W') p1Dir = 'UP';
    else if (key === 'S') p1Dir = 'DOWN';
    else if (key === 'A') p1Dir = 'LEFT';
    else if (key === 'D') p1Dir = 'RIGHT';

    if (p1Dir) {
      e.preventDefault();
      sendMove(0, p1Dir);
    }

    // Player 2: Flechas
    let p2Dir = null;
    if (key === 'ARROWUP') p2Dir = 'UP';
    else if (key === 'ARROWDOWN') p2Dir = 'DOWN';
    else if (key === 'ARROWLEFT') p2Dir = 'LEFT';
    else if (key === 'ARROWRIGHT') p2Dir = 'RIGHT';

    if (p2Dir) {
      e.preventDefault();
      sendMove(1, p2Dir);
    }
  });
}

function sendMove(playerIdx, direction) {
  if (gameConfig.multiplayer === 'online') {
    if (playerIdx === gameConfig.myIndex) {
      socketConn.emit('playerMove', direction);
    }
  } else {
    if (localGameInstance) {
      const socketId = playerIdx === 0 ? 'local_p1' : 'local_p2';
      localGameInstance.handleInput(socketId, direction);
    }
  }
}

// Controles Táctiles (Mobile Virtual Buttons + Swipe)
function setupTouchInput() {
  const btnUp = document.getElementById('tBtnUp');
  const btnDown = document.getElementById('tBtnDown');
  const btnLeft = document.getElementById('tBtnLeft');
  const btnRight = document.getElementById('tBtnRight');

  const handleTouch = (dir) => {
    const idx = gameConfig.multiplayer === 'online' ? gameConfig.myIndex : 0;
    sendMove(idx, dir);
  };

  btnUp.addEventListener('touchstart', (e) => { e.preventDefault(); handleTouch('UP'); });
  btnDown.addEventListener('touchstart', (e) => { e.preventDefault(); handleTouch('DOWN'); });
  btnLeft.addEventListener('touchstart', (e) => { e.preventDefault(); handleTouch('LEFT'); });
  btnRight.addEventListener('touchstart', (e) => { e.preventDefault(); handleTouch('RIGHT'); });

  // Swipe Gestures
  window.addEventListener('touchstart', (e) => {
    touchStartX = e.changedTouches[0].screenX;
    touchStartY = e.changedTouches[0].screenY;
  }, { passive: true });

  window.addEventListener('touchend', (e) => {
    const diffX = e.changedTouches[0].screenX - touchStartX;
    const diffY = e.changedTouches[0].screenY - touchStartY;
    
    if (Math.abs(diffX) > Math.abs(diffY)) {
      if (Math.abs(diffX) > 40) {
        handleTouch(diffX > 0 ? 'RIGHT' : 'LEFT');
      }
    } else {
      if (Math.abs(diffY) > 40) {
        handleTouch(diffY > 0 ? 'DOWN' : 'UP');
      }
    }
  }, { passive: true });
}

// --- CLASE MOTOR DE CABLE RUSH EN EL CLIENTE PARA JUEGOS LOCALES ---
// Asegura la misma lógica y física de colisiones en local sin desincronizaciones
class LocalSnakeEngine {
  constructor(playersList) {
    this.width = 30;
    this.height = 20;
    this.state = 'playing';
    this.duration = 0;
    this.tickCount = 0;
    this.items = [];
    this.powerups = [];
    this.winner = null;
    this.playersList = playersList;
    this.level = 1;        // nivel basado en duración
    this.scoreThreshold = 100; // puntos para subir de nivel

    this.initGame();
  }

  initGame() {
    this.players = this.playersList.map((p, idx) => {
      const isFirst = idx === 0;
      const startX = isFirst ? 5 : this.width - 6;
      const startY = Math.floor(this.height / 2);
      const initialDir = isFirst ? 'RIGHT' : 'LEFT';
      
      const segments = [];
      for (let i = 0; i < 3; i++) {
        segments.push({
          x: startX - (isFirst ? i : -i),
          y: startY
        });
      }

      return {
        socketId: p.socketId,
        name: p.name,
        character: p.character,
        playerIndex: p.playerIndex,
        segments,
        dir: initialDir,
        nextDir: initialDir,
        score: 0,
        isDead: false,
        overclockTicks: 0,
        firewallTicks: 0,
        empTicks: 0,
        ghostTicks: 0
      };
    });

    for (let i = 0; i < 3; i++) {
      this.spawnItem();
    }
    this.spawnPowerup();
  }

  handleInput(socketId, dir) {
    const player = this.players.find(p => p.socketId === socketId);
    if (!player || player.isDead || player.empTicks > 0) return;

    const curDir = player.dir;
    if (dir === 'UP' && curDir === 'DOWN') return;
    if (dir === 'DOWN' && curDir === 'UP') return;
    if (dir === 'LEFT' && curDir === 'RIGHT') return;
    if (dir === 'RIGHT' && curDir === 'LEFT') return;

    player.nextDir = dir;
  }

  isTileOccupied(x, y) {
    return this.players.some(p => 
      p.segments.some(seg => seg.x === x && seg.y === y)
    );
  }

  getRandomFreeTile() {
    let x, y, attempts = 0;
    do {
      x = Math.floor(Math.random() * (this.width - 2)) + 1;
      y = Math.floor(Math.random() * (this.height - 2)) + 1;
      attempts++;
      if (attempts > 100) break;
    } while (
      this.isTileOccupied(x, y) || 
      this.items.some(item => item.x === x && item.y === y) ||
      this.powerups.some(pu => pu.x === x && pu.y === y)
    );
    return { x, y };
  }

  spawnItem() {
    const tile = this.getRandomFreeTile();
    const rand = Math.random();
    let type = 'datos';
    if (rand > 0.6 && rand <= 0.9) type = 'energia';
    else if (rand > 0.9) type = 'nodo';
    this.items.push({ x: tile.x, y: tile.y, type });
  }

  spawnPowerup() {
    const tile = this.getRandomFreeTile();
    const types = ['overclock', 'firewall', 'emp', 'ghost'];
    const type = types[Math.floor(Math.random() * types.length)];
    this.powerups.push({ x: tile.x, y: tile.y, type });
  }

  tick() {
    if (this.state !== 'playing') return;

    this.tickCount++;
    if (this.tickCount % 10 === 0) {
      this.duration++;

      // Subir de nivel cada 20 segundos
      const newLevel = Math.min(5, 1 + Math.floor(this.duration / 20));
      if (newLevel !== this.level) {
        this.level = newLevel;
      }
    }

    this.players.forEach(player => {
      if (player.isDead) return;

      if (player.overclockTicks > 0) player.overclockTicks--;
      if (player.firewallTicks > 0) player.firewallTicks--;
      if (player.empTicks > 0) {
        player.empTicks--;
        return;
      }
      if (player.ghostTicks > 0) player.ghostTicks--;

      // Overclock hace que mueva cada tick; sin overclock, cada 2 ticks
      // NIVEL 3+: sin overclock igual mueve cada 1.5 ticks (más rápido)
      const skipTick = this.level >= 3
        ? (player.overclockTicks > 0 ? false : this.tickCount % 2 !== 0)   // nivel3: 2 de cada 3
        : (player.overclockTicks === 0 && this.tickCount % 2 === 0);       // normal

      if (skipTick) {
        return;
      }

      player.dir = player.nextDir;

      const head = { ...player.segments[0] };
      if (player.dir === 'UP') head.y--;
      else if (player.dir === 'DOWN') head.y++;
      else if (player.dir === 'LEFT') head.x--;
      else if (player.dir === 'RIGHT') head.x++;

      let hitWall = (head.x < 0 || head.x >= this.width || head.y < 0 || head.y >= this.height);
      if (hitWall) {
        if (player.firewallTicks > 0) {
          player.firewallTicks = 0;
          if (head.x < 0) head.x = this.width - 1;
          else if (head.x >= this.width) head.x = 0;
          else if (head.y < 0) head.y = this.height - 1;
          else if (head.y >= this.height) head.y = 0;
          hitWall = false;
        } else {
          player.isDead = true;
          return;
        }
      }

      let hitCable = false;
      this.players.forEach(other => {
        other.segments.forEach((seg, sIdx) => {
          if (seg.x === head.x && seg.y === head.y) {
            if (other.socketId === player.socketId && sIdx === 0) return;
            if (player.ghostTicks > 0) return;
            hitCable = true;
          }
        });
      });

      if (hitCable) {
        if (player.firewallTicks > 0) {
          player.firewallTicks = 0;
          return;
        } else {
          player.isDead = true;
          return;
        }
      }

      player.segments.unshift(head);

      let ate = false;
      const itemIdx = this.items.findIndex(item => item.x === head.x && item.y === head.y);
      if (itemIdx !== -1) {
        const item = this.items.splice(itemIdx, 1)[0];
        ate = true;
        
        let scoreAdd = 10;
        let growSegments = 1;
        if (item.type === 'datos') {
          scoreAdd = 10;
          growSegments = 1;
        } else if (item.type === 'energia') {
          scoreAdd = 25;
          growSegments = 2;
        } else if (item.type === 'nodo') {
          scoreAdd = 50;
          growSegments = 3;
        }

        player.score += scoreAdd;
        for (let i = 1; i < growSegments; i++) {
          player.segments.push({ ...player.segments[player.segments.length - 1] });
        }
        this.spawnItem();
      }

      const puIdx = this.powerups.findIndex(pu => pu.x === head.x && pu.y === head.y);
      if (puIdx !== -1) {
        const pu = this.powerups.splice(puIdx, 1)[0];
        ate = true;

        if (pu.type === 'overclock') {
          player.overclockTicks = 50;
        } else if (pu.type === 'firewall') {
          player.firewallTicks = 80;
        } else if (pu.type === 'emp') {
          this.players.forEach(other => {
            if (other.socketId !== player.socketId) {
              other.empTicks = 20;
            }
          });
        } else if (pu.type === 'ghost') {
          player.ghostTicks = 60;
        }

        setTimeout(() => {
          if (this.state === 'playing') {
            this.spawnPowerup();
          }
        }, 8000);
      }

      if (!ate) {
        player.segments.pop();
      }
    });

    this.checkGameOver();
  }

  checkGameOver() {
    const alivePlayers = this.players.filter(p => !p.isDead);

    if (alivePlayers.length === 0) {
      this.state = 'game_over';
      const p1 = this.players[0];
      const p2 = this.players[1];
      if (p1 && p2) {
        if (p1.score > p2.score) this.winner = p1.socketId;
        else if (p2.score > p1.score) this.winner = p2.socketId;
        else this.winner = 'draw';
      } else if (p1) {
        this.winner = 'none';
      }
    } else if (alivePlayers.length === 1 && this.players.length > 1) {
      this.state = 'game_over';
      this.winner = alivePlayers[0].socketId;
    } else if (this.players.length === 1 && alivePlayers.length === 0) {
      this.state = 'game_over';
      this.winner = 'none';
    }
  }

  getSerializedState() {
    return {
      width: this.width,
      height: this.height,
      state: this.state,
      duration: this.duration,
      level: this.level,
      winner: this.winner,
      items: this.items,
      powerups: this.powerups,
      players: this.players.map(p => ({
        socketId: p.socketId,
        name: p.name,
        character: p.character,
        playerIndex: p.playerIndex,
        segments: p.segments,
        dir: p.dir,
        score: p.score,
        isDead: p.isDead,
        overclock: p.overclockTicks > 0,
        firewall: p.firewallTicks > 0,
        emp: p.empTicks > 0,
        ghost: p.ghostTicks > 0
      }))
    };
  }
}
