// Renderizador de Cable Rush (Snake) en Canvas HTML5
// Usa imágenes de mapa de fondo y sprites de cable por personaje

// Cache de imágenes precargadas
const _snakeImgCache = {};

function _loadImg(src) {
  if (!_snakeImgCache[src]) {
    const img = new Image();
    img.src = src;
    _snakeImgCache[src] = img;
  }
  return _snakeImgCache[src];
}

// Precargar assets al inicio
(function preload() {
  [
    '/assets/characters/colaazul.png',
    '/assets/characters/colavioleta.png',
    '/assets/characters/colaverde.png'
  ].forEach(_loadImg);
})();

// Color del rastro por personaje
function _getCharColor(character) {
  if (character === 'USB')      return '#00f0ff';
  if (character === 'HDMI')     return '#bf00ff';
  if (character === 'Ethernet') return '#39ff14';
  return '#00f0ff';
}

// Imagen del cable por personaje
function _getCharImg(character) {
  if (character === 'USB')      return _loadImg('/assets/characters/colaazul.png');
  if (character === 'HDMI')     return _loadImg('/assets/characters/colavioleta.png');
  if (character === 'Ethernet') return _loadImg('/assets/characters/colaverde.png');
  return _loadImg('/assets/characters/colaazul.png');
}

// ─── Función principal de dibujo ─────────────────────────────
function drawSnakeGame(canvas, ctx, state) {
  const width  = state.width  || 30;
  const height = state.height || 20;
  const level  = state.level  || 1;

  const tileW = canvas.width  / width;
  const tileH = canvas.height / height;

  // 1. Limpiar pantalla
  ctx.fillStyle = '#060713';
  ctx.fillRect(0, 0, canvas.width, canvas.height);

  // 2. Grid Cyberpunk sobre el mapa
  ctx.save();
  ctx.strokeStyle = 'rgba(0, 240, 255, 0.05)';
  ctx.lineWidth = 1;
  for (let c = 0; c <= width; c++) {
    ctx.beginPath(); ctx.moveTo(c * tileW, 0); ctx.lineTo(c * tileW, canvas.height); ctx.stroke();
  }
  for (let r = 0; r <= height; r++) {
    ctx.beginPath(); ctx.moveTo(0, r * tileH); ctx.lineTo(canvas.width, r * tileH); ctx.stroke();
  }
  ctx.restore();

  // 3. Borde neon del canvas
  ctx.save();
  const borderColor = level >= 3 ? '#ff007f' : '#00f0ff';
  ctx.strokeStyle = borderColor;
  ctx.lineWidth = 3;
  ctx.shadowBlur = 14;
  ctx.shadowColor = borderColor;
  ctx.strokeRect(1, 1, canvas.width - 2, canvas.height - 2);
  ctx.restore();

  // 4. Items
  state.items.forEach(item => {
    const ix = item.x * tileW;
    const iy = item.y * tileH;
    ctx.save();

    if (item.type === 'datos') {
      ctx.fillStyle = '#00f0ff';
      ctx.shadowBlur = 8;
      ctx.shadowColor = '#00f0ff';
      ctx.fillRect(ix + 4, iy + 4, tileW - 8, tileH - 8);
      ctx.fillStyle = '#000';
      ctx.font = `bold ${Math.max(8, tileH * 0.5)}px monospace`;
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText(Math.floor(Date.now() / 800) % 2 === 0 ? '1' : '0', ix + tileW / 2, iy + tileH / 2);

    } else if (item.type === 'energia') {
      ctx.fillStyle = '#ffaa00';
      ctx.shadowBlur = 10;
      ctx.shadowColor = '#ffaa00';
      ctx.beginPath();
      ctx.moveTo(ix + tileW * 0.5,  iy + 2);
      ctx.lineTo(ix + tileW * 0.8,  iy + tileH * 0.5);
      ctx.lineTo(ix + tileW * 0.5,  iy + tileH * 0.5);
      ctx.lineTo(ix + tileW * 0.6,  iy + tileH - 2);
      ctx.lineTo(ix + tileW * 0.2,  iy + tileH * 0.5);
      ctx.lineTo(ix + tileW * 0.5,  iy + tileH * 0.5);
      ctx.closePath();
      ctx.fill();

    } else if (item.type === 'nodo') {
      const blink = Math.floor(Date.now() / 200) % 2 === 0;
      ctx.fillStyle   = blink ? '#39ff14' : '#ff007f';
      ctx.shadowBlur  = 12;
      ctx.shadowColor = ctx.fillStyle;
      ctx.beginPath();
      ctx.arc(ix + tileW / 2, iy + tileH / 2, Math.max(4, tileW * 0.3), 0, Math.PI * 2);
      ctx.fill();
      ctx.strokeStyle = blink ? '#ff007f' : '#39ff14';
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.arc(ix + tileW / 2, iy + tileH / 2, Math.max(6, tileW * 0.45), 0, Math.PI * 2);
      ctx.stroke();
    }

    ctx.restore();
  });

  // 5. Powerups
  state.powerups.forEach(pu => {
    const px = pu.x * tileW + tileW / 2;
    const py = pu.y * tileH + tileH / 2;
    ctx.save();

    let color = '#fff', symbol = '?';
    if (pu.type === 'overclock') { color = '#ffaa00'; symbol = '⚡'; }
    else if (pu.type === 'firewall') { color = '#db2777'; symbol = '🛡️'; }
    else if (pu.type === 'emp')      { color = '#0ea5e9'; symbol = '❄️'; }
    else if (pu.type === 'ghost')    { color = '#a855f7'; symbol = '👻'; }

    ctx.fillStyle   = 'rgba(0,0,0,0.65)';
    ctx.strokeStyle = color;
    ctx.lineWidth   = 2;
    ctx.shadowBlur  = 14;
    ctx.shadowColor = color;

    ctx.beginPath();
    ctx.moveTo(px,      py - 11);
    ctx.lineTo(px + 11, py);
    ctx.lineTo(px,      py + 11);
    ctx.lineTo(px - 11, py);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();

    ctx.fillStyle = color;
    ctx.font = '11px sans-serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(symbol, px, py);

    ctx.restore();
  });

  // 6. Cables (jugadores)
  state.players.forEach(p => {
    if (p.isDead) return;

    const baseColor = _getCharColor(p.character);
    const cableImg  = _getCharImg(p.character);

    ctx.save();
    if (p.ghost) ctx.globalAlpha = 0.5;

    // A. Cuerpo — segmentos con degradado de brillo
    p.segments.forEach((seg, index) => {
      const sx = seg.x * tileW;
      const sy = seg.y * tileH;

      ctx.save();
      ctx.shadowBlur  = index === 0 ? 14 : 5;
      ctx.shadowColor = baseColor;

      if (index === 0) {
        // CABEZA: dibujar imagen del cable si está lista, si no rectángulo
        if (cableImg.complete && cableImg.naturalWidth > 0) {
          ctx.drawImage(cableImg, sx - 1, sy - 1, tileW + 2, tileH + 2);
          // Borde neon encima
          ctx.strokeStyle = baseColor;
          ctx.lineWidth = 2;
          ctx.strokeRect(sx + 1, sy + 1, tileW - 2, tileH - 2);
        } else {
          ctx.fillStyle   = '#ffffff';
          ctx.strokeStyle = baseColor;
          ctx.lineWidth   = 2;
          ctx.fillRect(sx + 1, sy + 1, tileW - 2, tileH - 2);
          ctx.strokeRect(sx + 1, sy + 1, tileW - 2, tileH - 2);
        }
      } else {
        // CUERPO: color neón con alpha decreciente
        const ratio = 1 - (index / p.segments.length);
        const alpha = Math.max(0.25, ratio);
        ctx.globalAlpha = (p.ghost ? 0.5 : 1) * alpha;
        ctx.fillStyle   = baseColor;
        ctx.fillRect(sx + 2, sy + 2, tileW - 4, tileH - 4);
      }

      ctx.restore();
    });

    // B. Efectos powerup
    const head = p.segments[0];
    const hx   = head.x * tileW + tileW / 2;
    const hy   = head.y * tileH + tileH / 2;

    if (p.firewall) {
      ctx.strokeStyle = '#db2777';
      ctx.shadowBlur  = 14;
      ctx.shadowColor = '#db2777';
      ctx.lineWidth   = 2;
      ctx.beginPath();
      ctx.arc(hx, hy, 14 + Math.sin(Date.now() / 80) * 3, 0, Math.PI * 2);
      ctx.stroke();
    }

    if (p.emp) {
      ctx.fillStyle   = 'rgba(14,165,233,0.45)';
      ctx.strokeStyle = '#0ea5e9';
      ctx.lineWidth   = 1.5;
      ctx.fillRect(head.x * tileW - 1, head.y * tileH - 1, tileW + 2, tileH + 2);
      ctx.strokeRect(head.x * tileW - 1, head.y * tileH - 1, tileW + 2, tileH + 2);
    }

    if (p.overclock && Math.random() < 0.4) {
      ctx.fillStyle = '#ffaa00';
      ctx.beginPath();
      ctx.arc(hx + (Math.random() - 0.5) * 20, hy + (Math.random() - 0.5) * 20, 2, 0, Math.PI * 2);
      ctx.fill();
    }

    ctx.restore();
  });
}
