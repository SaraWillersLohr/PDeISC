// Lógica del motor de Cable Rush (Snake) - Servidor Autoritatitvo
class SnakeGame {
  constructor(roomCode, playersList) {
    this.roomCode = roomCode;
    this.playersList = playersList; // [{socketId, name, character, playerIndex}]
    this.width = 30;
    this.height = 20;
    this.state = 'playing'; // 'playing', 'game_over'
    
    this.items = []; // {x, y, type: 'datos'|'energia'|'nodo'}
    this.powerups = []; // {x, y, type: 'overclock'|'firewall'|'emp'|'ghost'}
    this.winner = null; // socketId del ganador
    this.duration = 0; // en segundos
    this.tickCount = 0;

    this.initGame();
  }

  initGame() {
    // Inicializar los dos jugadores en extremos opuestos
    this.players = this.playersList.map((p, idx) => {
      const isFirst = idx === 0;
      const startX = isFirst ? 5 : this.width - 6;
      const startY = Math.floor(this.height / 2);
      const initialDir = isFirst ? 'RIGHT' : 'LEFT';
      
      // Los cables crecen agregando segmentos. Empezamos con 3 segmentos.
      const segments = [];
      for (let i = 0; i < 3; i++) {
        segments.push({
          x: startX - (isFirst ? i : -i),
          y: startY
        });
      }

      return {
        socketId: p.socketId,
        name: p.name,
        character: p.character, // 'USB', 'HDMI', 'Ethernet'
        playerIndex: p.playerIndex,
        segments,
        dir: initialDir,
        nextDir: initialDir,
        score: 0,
        isDead: false,
        
        // Estados de Power-ups (representados en ticks de duración)
        overclockTicks: 0,
        firewallTicks: 0, // Escudo
        empTicks: 0,      // Congelado
        ghostTicks: 0,    // Atravesar obstáculos
        
        victories: 0
      };
    });

    // Spawnear items iniciales
    for (let i = 0; i < 3; i++) {
      this.spawnItem();
    }
    this.spawnPowerup();
  }

  // Maneja los comandos de cambio de dirección
  handleInput(socketId, dir) {
    const player = this.players.find(p => p.socketId === socketId);
    if (!player || player.isDead || player.empTicks > 0) return;

    // Prevenir giro de 180 grados directo
    const curDir = player.dir;
    if (dir === 'UP' && curDir === 'DOWN') return;
    if (dir === 'DOWN' && curDir === 'UP') return;
    if (dir === 'LEFT' && curDir === 'RIGHT') return;
    if (dir === 'RIGHT' && curDir === 'LEFT') return;

    player.nextDir = dir;
  }

  // Verifica si una coordenada está ocupada por algún cable
  isTileOccupied(x, y) {
    return this.players.some(p => 
      p.segments.some(seg => seg.x === x && seg.y === y)
    );
  }

  // Obtiene una coordenada aleatoria libre
  getRandomFreeTile() {
    let x, y, attempts = 0;
    do {
      x = Math.floor(Math.random() * (this.width - 2)) + 1;
      y = Math.floor(Math.random() * (this.height - 2)) + 1;
      attempts++;
      if (attempts > 100) break; // Evita bucle infinito si la pantalla está llena
    } while (
      this.isTileOccupied(x, y) || 
      this.items.some(item => item.x === x && item.y === y) ||
      this.powerups.some(pu => pu.x === x && pu.y === y)
    );
    return { x, y };
  }

  // Genera un item de puntaje común
  spawnItem() {
    const tile = this.getRandomFreeTile();
    const rand = Math.random();
    let type = 'datos'; // 60%
    if (rand > 0.6 && rand <= 0.9) {
      type = 'energia'; // 30%
    } else if (rand > 0.9) {
      type = 'nodo'; // 10%
    }

    this.items.push({ x: tile.x, y: tile.y, type });
  }

  // Genera un powerup aleatorio
  spawnPowerup() {
    const tile = this.getRandomFreeTile();
    const types = ['overclock', 'firewall', 'emp', 'ghost'];
    const type = types[Math.floor(Math.random() * types.length)];
    this.powerups.push({ x: tile.x, y: tile.y, type });
  }

  // Avanza el estado de Cable Rush por un Tick de juego
  tick() {
    if (this.state !== 'playing') return;

    this.tickCount++;
    if (this.tickCount % 10 === 0) {
      this.duration++; // Incrementar duración en segundos (10 ticks = 1 segundo aprox)
    }

    // Cada jugador decide si se mueve en este tick
    this.players.forEach(player => {
      if (player.isDead) return;

      // Disminuir contadores de Power-up
      if (player.overclockTicks > 0) player.overclockTicks--;
      if (player.firewallTicks > 0) player.firewallTicks--;
      if (player.empTicks > 0) {
        player.empTicks--;
        return; // Si está congelado por EMP, no se mueve en este tick
      }
      if (player.ghostTicks > 0) player.ghostTicks--;

      // Lógica de velocidad del Overclock
      // Si tiene overclock, se mueve cada tick.
      // Si NO tiene overclock, se mueve en ticks pares para ir a mitad de velocidad.
      if (player.overclockTicks === 0 && this.tickCount % 2 === 0) {
        return; 
      }

      // Actualizar dirección actual a la dirección elegida
      player.dir = player.nextDir;

      // Calcular nueva cabeza
      const head = { ...player.segments[0] };
      if (player.dir === 'UP') head.y--;
      else if (player.dir === 'DOWN') head.y++;
      else if (player.dir === 'LEFT') head.x--;
      else if (player.dir === 'RIGHT') head.x++;

      // Verificar colisión con bordes
      let hitWall = (head.x < 0 || head.x >= this.width || head.y < 0 || head.y >= this.height);
      if (hitWall) {
        if (player.firewallTicks > 0) {
          // Si tiene escudo Firewall, envuelve/traspasa al lado opuesto (warp)
          player.firewallTicks = 0; // Consume escudo
          if (head.x < 0) head.x = this.width - 1;
          else if (head.x >= this.width) head.x = 0;
          else if (head.y < 0) head.y = this.height - 1;
          else if (head.y >= this.height) head.y = 0;
          hitWall = false;
        } else {
          player.isDead = true;
          return;
        }
      }

      // Colisión con cables (sí mismo o rival)
      let hitCable = false;
      this.players.forEach(other => {
        other.segments.forEach((seg, sIdx) => {
          // Si colisiona con cualquier segmento
          if (seg.x === head.x && seg.y === head.y) {
            // Si soy yo mismo en la cabeza, no cuenta
            if (other.socketId === player.socketId && sIdx === 0) return;
            
            if (player.ghostTicks > 0) {
              // Ghost mode permite atravesar segmentos sin morir
              return;
            }
            hitCable = true;
          }
        });
      });

      if (hitCable) {
        if (player.firewallTicks > 0) {
          player.firewallTicks = 0; // Consume escudo
          // Sobrevive: no avanza el cuerpo, simplemente se queda quieto este tick
          return;
        } else {
          player.isDead = true;
          return;
        }
      }

      // Insertar nueva cabeza
      player.segments.unshift(head);

      // Comprobar consumo de Items de Datos y Energía
      let ate = false;
      const itemIdx = this.items.findIndex(item => item.x === head.x && item.y === head.y);
      if (itemIdx !== -1) {
        const item = this.items.splice(itemIdx, 1)[0];
        ate = true;
        
        let scoreAdd = 10;
        let growSegments = 1;
        if (item.type === 'datos') {
          scoreAdd = 10;
          growSegments = 1;
        } else if (item.type === 'energia') {
          scoreAdd = 25;
          growSegments = 2;
        } else if (item.type === 'nodo') {
          scoreAdd = 50;
          growSegments = 3;
        }

        player.score += scoreAdd;
        // La cabeza ya se insertó (unshift).
        // Si no creciera, haríamos pop() para mantener tamaño.
        // Como crece, quitamos el pop() por los segmentos extra.
        // Si crece 1, no hacemos pop. Si crece 2, duplicamos la cola para simular crecimiento extra.
        for (let i = 1; i < growSegments; i++) {
          player.segments.push({ ...player.segments[player.segments.length - 1] });
        }

        // Spawnear nuevo item
        this.spawnItem();
      }

      // Comprobar consumo de Power-ups
      const puIdx = this.powerups.findIndex(pu => pu.x === head.x && pu.y === head.y);
      if (puIdx !== -1) {
        const pu = this.powerups.splice(puIdx, 1)[0];
        ate = true;

        if (pu.type === 'overclock') {
          player.overclockTicks = 50; // 5 segundos de velocidad máxima
        } else if (pu.type === 'firewall') {
          player.firewallTicks = 80; // Escudo por 8 segundos
        } else if (pu.type === 'emp') {
          // Congela al oponente por 2 segundos (20 ticks)
          this.players.forEach(other => {
            if (other.socketId !== player.socketId) {
              other.empTicks = 20;
            }
          });
        } else if (pu.type === 'ghost') {
          player.ghostTicks = 60; // 6 segundos de atravesar obstáculos
        }

        // Spawnear nuevo powerup tras consumir
        setTimeout(() => {
          if (this.state === 'playing') {
            this.spawnPowerup();
          }
        }, 8000);
      }

      // Si no comió nada, eliminar cola para mantener tamaño normal
      if (!ate) {
        player.segments.pop();
      }
    });

    // Validar condiciones de fin de partida
    this.checkGameOver();
  }

  // Verifica si queda algún superviviente o si se empató
  checkGameOver() {
    const alivePlayers = this.players.filter(p => !p.isDead);

    if (alivePlayers.length === 0) {
      // Ambos murieron en el mismo tick. Empate o gana el de mayor puntuación
      this.state = 'game_over';
      const p1 = this.players[0];
      const p2 = this.players[1];
      if (p1 && p2) {
        if (p1.score > p2.score) {
          this.winner = p1.socketId;
        } else if (p2.score > p1.score) {
          this.winner = p2.socketId;
        } else {
          this.winner = 'draw'; // Empate absoluto
        }
      }
    } else if (alivePlayers.length === 1 && this.players.length > 1) {
      // En modo versus online, queda 1 superviviente de 2
      this.state = 'game_over';
      this.winner = alivePlayers[0].socketId;
    } else if (this.players.length === 1 && alivePlayers.length === 0) {
      // Modo 1 jugador local (si aplica, aunque Cable Rush online es de 2)
      this.state = 'game_over';
      this.winner = 'none';
    }
  }

  // Retorna el estado JSON serializable
  getSerializedState() {
    return {
      width: this.width,
      height: this.height,
      state: this.state,
      duration: this.duration,
      winner: this.winner,
      items: this.items,
      powerups: this.powerups,
      players: this.players.map(p => ({
        socketId: p.socketId,
        name: p.name,
        character: p.character,
        playerIndex: p.playerIndex,
        segments: p.segments,
        dir: p.dir,
        score: p.score,
        isDead: p.isDead,
        overclock: p.overclockTicks > 0,
        firewall: p.firewallTicks > 0,
        emp: p.empTicks > 0,
        ghost: p.ghostTicks > 0
      }))
    };
  }
}

module.exports = SnakeGame;
