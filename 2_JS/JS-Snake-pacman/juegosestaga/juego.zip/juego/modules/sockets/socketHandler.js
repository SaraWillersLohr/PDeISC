const roomManager = require('../rooms/roomManager');
const PacmanGame = require('../games/pacmanGame');
const SnakeGame = require('../games/snakeGame');
const leaderboardManager = require('../leaderboard/leaderboardManager');

function initSocketHandler(io) {
  io.on('connection', (socket) => {
    console.log(`Usuario conectado: ${socket.id}`);

    // Evento: Crear sala
    socket.on('createRoom', ({ game }) => {
      const room = roomManager.createRoom(game);
      if (!room) {
        return socket.emit('errorMsg', { message: 'No se pudo crear la sala. Juego inválido.' });
      }
      
      socket.join(room.code);
      socket.roomCode = room.code;
      console.log(`Sala creada: ${room.code} para el juego: ${game}`);
      socket.emit('roomCreated', room.code);
    });

    // Evento: Unirse a sala
    socket.on('joinRoom', ({ code, name, character }) => {
      // Validación 2: JavaScript en servidor (Backend checks)
      if (!name || name.trim().length < 3 || name.trim().length > 10) {
        return socket.emit('errorMsg', { message: 'El nombre debe tener entre 3 y 10 caracteres.' });
      }

      const result = roomManager.joinRoom(code, socket.id, name, character);
      if (!result.success) {
        return socket.emit('errorMsg', { message: result.error });
      }

      socket.join(code);
      socket.roomCode = code;
      
      console.log(`Usuario ${name} (${character}) se unió a la sala: ${code}`);

      // Notificar a todos en la sala que un jugador se unió
      io.to(code).emit('playerJoined', {
        room: serializeRoom(result.room),
        player: result.player
      });
    });

    // Evento: Jugador está Listo (Ready)
    socket.on('ready', () => {
      const code = socket.roomCode;
      if (!code) return;

      const room = roomManager.getRoom(code);
      if (!room) return;

      const allReady = roomManager.setPlayerReady(code, socket.id);
      
      // Notificar cambio de estado en la sala
      io.to(code).emit('roomUpdated', serializeRoom(room));

      if (allReady) {
        console.log(`Comenzando partida multijugador en sala: ${code}`);
        startGame(io, room);
      }
    });

    // Evento: Movimiento en tiempo real (Input del jugador)
    socket.on('playerMove', (direction) => {
      const code = socket.roomCode;
      if (!code) return;

      const room = roomManager.getRoom(code);
      if (!room || !room.gameInstance) return;

      // El server recibe el input y actualiza el motor de juego
      room.gameInstance.handleInput(socket.id, direction);
    });

    // Evento: Reiniciar partida
    socket.on('restartGame', () => {
      const code = socket.roomCode;
      if (!code) return;

      const room = roomManager.getRoom(code);
      if (!room) return;

      // Resetear estados
      if (room.gameInterval) {
        clearInterval(room.gameInterval);
        room.gameInterval = null;
      }
      room.players.forEach(p => p.ready = false);
      room.status = 'waiting';
      room.gameInstance = null;
      room.savedLeaderboard = false;

      io.to(code).emit('gameRestarted', serializeRoom(room));
    });

    // Evento: Desconexión
    socket.on('disconnect', () => {
      console.log(`Usuario desconectado: ${socket.id}`);
      
      const leaveResult = roomManager.removePlayer(socket.id);
      if (leaveResult) {
        const { code, room, destroyed, disconnectedPlayerName } = leaveResult;
        console.log(`Jugador ${disconnectedPlayerName} abandonó la sala ${code}`);

        if (destroyed) {
          console.log(`Sala ${code} destruida por falta de jugadores.`);
        } else {
          // Si queda un jugador, notificarle y resetear sala a espera
          io.to(code).emit('playerDisconnected', {
            message: `El jugador ${disconnectedPlayerName} se desconectó. La sala volvió al lobby.`,
            room: serializeRoom(room)
          });
        }
      }
    });
  });
}

// Auxiliar para serializar datos limpios de la sala para el cliente
function serializeRoom(room) {
  return {
    code: room.code,
    game: room.game,
    status: room.status,
    players: room.players.map(p => ({
      name: p.name,
      character: p.character,
      ready: p.ready,
      playerIndex: p.playerIndex
    }))
  };
}

// Inicia el loop del juego y configura el intervalo
function startGame(io, room) {
  room.savedLeaderboard = false;

  // Instanciar motor de juego
  if (room.game === 'pacman') {
    room.gameInstance = new PacmanGame(room.code, room.players);
  } else {
    room.gameInstance = new SnakeGame(room.code, room.players);
  }

  // Notificar inicio
  io.to(room.code).emit('gameStarted', {
    room: serializeRoom(room),
    gameState: room.gameInstance.getSerializedState()
  });

  // Determinar velocidad de refresco (Pacman: ~30 FPS, Snake: ~10 FPS)
  const fps = room.game === 'pacman' ? 30 : 10;
  const tickInterval = 1000 / fps;

  room.gameInterval = setInterval(() => {
    if (!room.gameInstance) return;

    room.gameInstance.tick();
    const state = room.gameInstance.getSerializedState();

    // Enviar el gameState completo a toda la sala
    io.to(room.code).emit('gameState', state);

    // Si terminó la partida, guardar leaderboard y limpiar
    if (state.state === 'game_over' || state.state === 'victory') {
      clearInterval(room.gameInterval);
      room.gameInterval = null;

      // Guardar puntajes en persistencia JSON si no se han guardado
      if (!room.savedLeaderboard) {
        room.savedLeaderboard = true;
        saveScoresToLeaderboard(room, state);
      }
      
      io.to(room.code).emit('gameOver', {
        gameState: state
      });
    }
  }, tickInterval);
}

// Persiste las puntuaciones correspondientes al terminar la partida
function saveScoresToLeaderboard(room, finalState) {
  const game = room.game;
  
  if (game === 'pacman') {
    // Escape Escolar es cooperativo. Guardamos las puntuaciones individuales de ambos jugadores
    finalState.players.forEach(p => {
      leaderboardManager.addScore('pacman', {
        name: p.name,
        score: finalState.score, // En Coop se comparte el score grupal
        character: p.character,
        duration: 0, // No trackeado o 0
        victories: finalState.state === 'victory' ? 1 : 0
      });
    });
  } else if (game === 'snake') {
    // Cable Rush es competitivo.
    finalState.players.forEach(p => {
      const isWinner = (finalState.winner === p.socketId) || (finalState.winner === 'draw');
      leaderboardManager.addScore('snake', {
        name: p.name,
        score: p.score,
        character: p.character,
        duration: finalState.duration,
        victories: isWinner ? 1 : 0
      });
    });
  }
}

module.exports = {
  initSocketHandler
};
