// Cliente Socket.IO e Integración de Lobby de Matchmaking
const socket = io();

let selectedGame = localStorage.getItem('selectedGame') || 'pacman';
let gameMode = '1P'; // '1P' o '2P'
let mpType = 'local'; // 'local' o 'online'
let activeRoom = null;

// Datos de Personajes por Juego
const CHARACTERS = {
  pacman: [
    { id: 'Sara', name: 'Sara', desc: 'Velocidad\nbase', color: '#ff007f', selColor: '#ff007f', img: 'sarapix.png' },
    { id: 'Male', name: 'Male', desc: 'Gran\nagilidad', color: '#00f0ff', selColor: '#00f0ff', img: 'malepix.png' }
  ],
  snake: [
    { id: 'USB',     name: 'Cable USB',     desc: 'Rastro\ncyan',    color: '#00f0ff', selColor: '#00f0ff', img: 'colaazul.png'    },
    { id: 'HDMI',    name: 'Cable HDMI',    desc: 'Rastro\nvioleta', color: '#bf00ff', selColor: '#bf00ff', img: 'colavioleta.png' },
    { id: 'Ethernet',name: 'Cable Ethernet',desc: 'Rastro\nverde',   color: '#39ff14', selColor: '#39ff14', img: 'colaverde.png'   }
  ]
};

// Al cargar el documento, renderizar dinámicamente personajes y configurar el formulario
document.addEventListener('DOMContentLoaded', () => {
  renderCharacters();
  setMode('1P'); // Modo por defecto

  // Actualizar título del lobby
  const lobbyTitle = document.getElementById('lobbyTitle');
  if (lobbyTitle) {
    lobbyTitle.textContent = selectedGame === 'pacman' ? 'Configurar Escape Escolar' : 'Configurar Cable Rush';
  }
});

// Renderizar la selección de personajes dinámicamente
function renderCharacters() {
  const container = document.getElementById('characterSelectContainer');
  if (!container) return;

  container.innerHTML = '';
  const list = CHARACTERS[selectedGame] || [];

  list.forEach(char => {
    const col = document.createElement('div');
    col.className = 'col-sm-6 col-md-4';

    const imgPath = `/assets/characters/${char.img}`;

    col.innerHTML = `
      <div class="select-char-card"
           id="char-${char.id}"
           style="color: ${char.color}; border-color: ${char.color}33; --sel-color: ${char.selColor};"
           onclick="selectCharacter('${char.id}')">
        <span class="char-selected-badge">✓ ELEGIDO</span>
        <img src="${imgPath}" alt="${char.name}" class="char-img">
        <h4 class="char-name" style="color: ${char.color};">${char.name}</h4>
        <p class="char-desc">${char.desc}</p>
      </div>
    `;
    container.appendChild(col);
  });
}

// Selecciona un personaje y actualiza clases visuales
function selectCharacter(charId) {
  // Deseleccionar anteriores
  document.querySelectorAll('.select-char-card').forEach(c => {
    c.classList.remove('char-selected', 'border-primary', 'bg-opacity-50');
  });

  // Seleccionar actual
  const card = document.getElementById(`char-${charId}`);
  if (card) {
    card.classList.add('char-selected');
  }

  document.getElementById('selectedCharacter').value = charId;
  document.getElementById('characterErr').style.display = 'none';

  // Sonido retro
  if (window.audioSynth) {
    window.audioSynth.playSelect();
  }
}

// Configura el modo de juego
function setMode(mode) {
  gameMode = mode;
  const btn1P = document.getElementById('btnMode1P');
  const btn2P = document.getElementById('btnMode2P');
  const mpOpts = document.getElementById('multiplayerOptions');
  const startBtn = document.getElementById('btnStartGameLocal');

  if (mode === '1P') {
    btn1P.classList.remove('btn-neon-pink');
    btn1P.classList.add('bg-primary', 'text-black');
    btn2P.classList.remove('bg-primary', 'text-black');
    btn2P.classList.add('btn-neon-pink');

    mpOpts.style.display = 'none';
    startBtn.style.display = 'block';
    startBtn.textContent = 'Iniciar Partida Local';
  } else {
    btn2P.classList.remove('btn-neon-pink');
    btn2P.classList.add('bg-primary', 'text-black');
    btn1P.classList.remove('bg-primary', 'text-black');
    btn1P.classList.add('btn-neon-pink');

    mpOpts.style.display = 'block';
    setMultiplayerType(mpType);
  }
}

// Configura tipo de multijugador (Local o Online)
function setMultiplayerType(type) {
  mpType = type;
  const btnLocal = document.getElementById('btnTypeLocal');
  const btnOnline = document.getElementById('btnTypeOnline');
  const onlineSection = document.getElementById('onlineRoomSection');
  const startBtn = document.getElementById('btnStartGameLocal');

  if (type === 'local') {
    btnLocal.classList.remove('btn-neon-pink');
    btnLocal.classList.add('bg-primary', 'text-black');
    btnOnline.classList.remove('bg-primary', 'text-black');
    btnOnline.classList.add('btn-neon-pink');

    onlineSection.style.display = 'none';
    startBtn.style.display = 'block';
    startBtn.textContent = 'Iniciar Partida Local (2P)';
  } else {
    btnOnline.classList.remove('btn-neon-pink');
    btnOnline.classList.add('bg-primary', 'text-black');
    btnLocal.classList.remove('bg-primary', 'text-black');
    btnLocal.classList.add('btn-neon-pink');

    onlineSection.style.display = 'block';
    startBtn.style.display = 'none';
  }
}

function showJoinCodeInput() {
  const container = document.getElementById('joinCodeContainer');
  container.style.display = container.style.display === 'none' ? 'block' : 'none';
}

// Validación JavaScript de Formulario y Campos
function validateInputs() {
  const nameInput = document.getElementById('playerName');
  const character = document.getElementById('selectedCharacter').value;

  let valid = true;

  if (!nameInput.checkValidity()) {
    nameInput.classList.add('is-invalid');
    valid = false;
  } else {
    nameInput.classList.remove('is-invalid');
  }

  if (!character) {
    document.getElementById('characterErr').style.display = 'block';
    valid = false;
  } else {
    document.getElementById('characterErr').style.display = 'none';
  }

  return valid;
}

// --- LOGICA DE JUEGO LOCAL ---
function handleStartLocalGame() {
  if (!validateInputs()) return;

  const nickname = document.getElementById('playerName').value;
  const character = document.getElementById('selectedCharacter').value;

  const gameConfig = {
    mode: gameMode,
    multiplayer: mpType,
    p1Name: nickname,
    p1Character: character
  };

  sessionStorage.setItem('gameConfig', JSON.stringify(gameConfig));
  window.location.href = `/${selectedGame}`;
}

// --- LOGICA DE SALAS ONLINE (SOCKET.IO) ---
function handleCreateOnlineRoom() {
  if (!validateInputs()) return;
  socket.emit('createRoom', { game: selectedGame });
}

function handleJoinOnlineRoom() {
  if (!validateInputs()) return;

  const codeInput = document.getElementById('roomCodeInput');
  const code = codeInput.value.toUpperCase();

  if (!code || code.length !== 4 || !/^[A-Z]{4}$/.test(code)) {
    codeInput.classList.add('is-invalid');
    document.getElementById('codeErr').style.display = 'block';
    return;
  }

  codeInput.classList.remove('is-invalid');
  document.getElementById('codeErr').style.display = 'none';

  const nickname = document.getElementById('playerName').value;
  const character = document.getElementById('selectedCharacter').value;

  socket.emit('joinRoom', { code, name: nickname, character });
}

// Al recibir que se creó la sala
socket.on('roomCreated', (code) => {
  const nickname = document.getElementById('playerName').value;
  const character = document.getElementById('selectedCharacter').value;
  socket.emit('joinRoom', { code, name: nickname, character });
});

// Al unirse exitosamente a una sala o actualizarse
socket.on('playerJoined', ({ room, player }) => {
  activeRoom = room;
  switchToWaitingLobby();
  updatePlayersList();

  if (window.audioSynth) {
    window.audioSynth.playCoin();
  }
});

// Actualizaciones de la sala
socket.on('roomUpdated', (room) => {
  activeRoom = room;
  updatePlayersList();
});

// Cambia la vista del formulario al Lobby de Sockets
function switchToWaitingLobby() {
  document.getElementById('lobbyForm').style.display = 'none';
  document.getElementById('onlineLobbyWaiting').style.display = 'block';
  document.getElementById('roomCodeDisplay').textContent = activeRoom.code;
}

// Re-renderiza la lista de jugadores en la sala
function updatePlayersList() {
  const container = document.getElementById('onlinePlayersList');
  if (!container || !activeRoom) return;

  container.innerHTML = '';

  activeRoom.players.forEach(p => {
    const div = document.createElement('div');
    div.className = 'd-flex justify-content-between align-items-center p-2 rounded bg-black bg-opacity-40 border border-secondary-subtle';
    div.innerHTML = `
      <div class="text-start">
        <span class="text-arcade font-bold ${p.playerIndex === 0 ? 'text-info' : 'text-danger'}">${p.name}</span>
        <span class="text-secondary small ms-2">(${p.character})</span>
      </div>
      <div>
        ${p.ready
          ? '<span class="badge bg-success text-arcade px-2 py-1 fs-7">Listo</span>'
          : '<span class="badge bg-warning text-dark text-arcade px-2 py-1 fs-7">Esperando</span>'
        }
      </div>
    `;
    container.appendChild(div);
  });

  if (activeRoom.players.length < 2) {
    const div = document.createElement('div');
    div.className = 'p-2 rounded border border-dashed text-secondary text-center small';
    div.textContent = 'Esperando a que se una el Jugador 2...';
    container.appendChild(div);
  }
}

// Envía estado Ready al servidor
function handleSendReady() {
  socket.emit('ready');
  document.getElementById('btnReady').disabled = true;
  document.getElementById('btnReady').textContent = 'Esperando Rival...';
}

// Abandona sala
function handleExitRoom() {
  window.location.reload();
}

// Desconexión de rival
socket.on('playerDisconnected', ({ message, room }) => {
  activeRoom = room;
  updatePlayersList();

  document.getElementById('btnReady').disabled = false;
  document.getElementById('btnReady').textContent = '¡Listo! (Ready)';

  showCustomAlert(message);
});

// Comienzo de la partida multijugador online
socket.on('gameStarted', ({ room, gameState }) => {
  const gameConfig = {
    mode: '2P',
    multiplayer: 'online',
    roomCode: room.code,
    players: room.players,
    myIndex: room.players.findIndex(p => p.name === document.getElementById('playerName').value)
  };

  sessionStorage.setItem('gameConfig', JSON.stringify(gameConfig));
  window.location.href = `/${selectedGame}`;
});

// Manejo de errores personalizados desde backend
socket.on('errorMsg', ({ message }) => {
  showCustomAlert(message);
});

// --- ALERTAS PERSONALIZADAS ---
function showCustomAlert(msg) {
  document.getElementById('customAlertMessage').textContent = msg;
  document.getElementById('customAlertOverlay').classList.add('active');
  if (window.audioSynth) {
    window.audioSynth.playGameOver();
  }
}

function closeCustomAlert() {
  document.getElementById('customAlertOverlay').classList.remove('active');
}
