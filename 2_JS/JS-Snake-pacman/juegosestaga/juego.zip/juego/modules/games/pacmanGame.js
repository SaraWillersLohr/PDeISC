// Lógica del motor de Escape Escolar (Pac-Man) - Servidor Autoritativo
const MAPS = {
  1: [
    [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1],
    [1,3,2,2,2,2,2,1,2,2,2,2,2,3,1],
    [1,2,1,1,2,1,2,1,2,1,2,1,1,2,1],
    [1,2,1,1,2,1,2,2,2,1,2,1,1,2,1],
    [1,2,2,2,2,2,2,1,2,2,2,2,2,2,1],
    [1,2,1,1,2,1,1,1,1,1,2,1,1,2,1],
    [1,2,2,2,2,2,2,7,2,2,2,2,2,2,1],
    [1,1,1,2,1,1,7,7,7,1,1,2,1,1,1],
    [1,2,2,2,2,2,2,7,2,2,2,2,2,2,1],
    [1,2,1,1,2,1,1,1,1,1,2,1,1,2,1],
    [1,2,2,2,2,2,2,1,2,2,2,2,2,2,1],
    [1,2,1,1,2,1,2,2,2,1,2,1,1,2,1],
    [1,2,1,1,2,1,2,1,2,1,2,1,1,2,1],
    [1,3,2,2,2,2,2,1,2,2,2,2,2,3,1],
    [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1]
  ],
  2: [
    [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1],
    [1,3,2,2,2,2,1,1,1,1,1,2,2,2,2,3,1],
    [1,2,1,1,1,2,2,2,1,2,2,2,1,1,1,2,1],
    [1,2,1,1,1,1,1,2,1,2,1,1,1,1,1,2,1],
    [1,2,2,2,1,2,2,2,2,2,2,2,1,2,2,2,1],
    [1,1,1,2,1,2,1,1,7,1,1,2,1,2,1,1,1],
    [1,1,1,2,2,2,1,7,7,7,1,2,2,2,1,1,1],
    [1,1,1,2,1,2,1,1,1,1,1,2,1,2,1,1,1],
    [1,2,2,2,1,2,2,2,2,2,2,2,1,2,2,2,1],
    [1,2,1,1,1,1,1,2,1,2,1,1,1,1,1,2,1],
    [1,2,1,1,1,2,2,2,1,2,2,2,1,1,1,2,1],
    [1,3,2,2,2,2,1,1,1,1,1,2,2,2,2,3,1],
    [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1]
  ],
  3: [
    [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1],
    [1,3,2,2,2,2,2,2,2,1,2,2,2,2,2,2,2,3,1],
    [1,2,1,1,2,1,1,1,2,1,2,1,1,1,2,1,1,2,1],
    [1,2,1,1,2,1,1,1,2,1,2,1,1,1,2,1,1,2,1],
    [1,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,1],
    [1,2,1,1,2,1,2,1,1,1,1,1,2,1,2,1,1,2,1],
    [1,2,2,2,2,1,2,2,2,1,2,2,2,1,2,2,2,2,1],
    [1,1,1,1,2,1,1,1,2,1,2,1,1,1,2,1,1,1,1],
    [1,1,1,1,2,1,7,7,7,7,7,7,7,1,2,1,1,1,1],
    [1,1,1,1,2,1,7,1,1,7,1,1,7,1,2,1,1,1,1],
    [1,1,1,1,2,1,7,7,7,7,7,7,7,1,2,1,1,1,1],
    [1,1,1,1,2,1,1,1,2,1,2,1,1,1,2,1,1,1,1],
    [1,2,2,2,2,1,2,2,2,1,2,2,2,1,2,2,2,2,1],
    [1,2,1,1,2,1,2,1,1,1,1,1,2,1,2,1,1,2,1],
    [1,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,1],
    [1,2,1,1,2,1,1,1,2,1,2,1,1,1,2,1,1,2,1],
    [1,2,1,1,2,1,1,1,2,1,2,1,1,1,2,1,1,2,1],
    [1,3,2,2,2,2,2,2,2,1,2,2,2,2,2,2,2,3,1],
    [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1]
  ],
  4: [
    [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1],
    [1,3,2,2,2,2,2,2,2,2,1,2,2,2,2,2,2,2,2,3,1],
    [1,2,1,1,1,2,1,1,1,2,1,2,1,1,1,2,1,1,1,2,1],
    [1,2,1,1,1,2,1,1,1,2,1,2,1,1,1,2,1,1,1,2,1],
    [1,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,1],
    [1,2,1,1,1,2,1,2,1,1,1,1,1,2,1,2,1,1,1,2,1],
    [1,2,2,2,2,2,1,2,2,2,1,2,2,2,1,2,2,2,2,2,1],
    [1,1,1,1,1,2,1,1,1,2,1,2,1,1,1,2,1,1,1,1,1],
    [1,1,1,1,1,2,1,7,7,7,7,7,7,7,1,2,1,1,1,1,1],
    [1,1,1,1,1,2,1,7,1,1,1,1,1,7,1,2,1,1,1,1,1],
    [1,2,2,2,2,2,2,7,1,1,1,1,1,7,2,2,2,2,2,2,1],
    [1,1,1,1,1,2,1,7,1,1,1,1,1,7,1,2,1,1,1,1,1],
    [1,1,1,1,1,2,1,7,7,7,7,7,7,7,1,2,1,1,1,1,1],
    [1,1,1,1,1,2,1,1,1,2,1,2,1,1,1,2,1,1,1,1,1],
    [1,2,2,2,2,2,1,2,2,2,1,2,2,2,1,2,2,2,2,2,1],
    [1,2,1,1,1,2,1,2,1,1,1,1,1,2,1,2,1,1,1,2,1],
    [1,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,1],
    [1,2,1,1,1,2,1,1,1,2,1,2,1,1,1,2,1,1,1,2,1],
    [1,2,1,1,1,2,1,1,1,2,1,2,1,1,1,2,1,1,1,2,1],
    [1,3,2,2,2,2,2,2,2,2,1,2,2,2,2,2,2,2,2,3,1],
    [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1]
  ],
  5: [
    [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1],
    [1,3,2,2,2,2,2,2,2,2,2,1,2,2,2,2,2,2,2,2,2,3,1],
    [1,2,1,1,1,2,1,1,1,1,2,1,2,1,1,1,1,2,1,1,1,2,1],
    [1,2,1,1,1,2,1,1,1,1,2,1,2,1,1,1,1,2,1,1,1,2,1],
    [1,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,1],
    [1,2,1,1,1,2,1,2,1,1,1,1,1,1,1,2,1,2,1,1,1,2,1],
    [1,2,2,2,2,2,1,2,2,2,2,1,2,2,2,2,1,2,2,2,2,2,1],
    [1,1,1,1,1,2,1,1,1,1,2,1,2,1,1,1,1,2,1,1,1,1,1],
    [1,1,1,1,1,2,1,2,2,2,2,2,2,2,2,2,1,2,1,1,1,1,1],
    [1,1,1,1,1,2,1,2,1,1,1,7,1,1,1,2,1,2,1,1,1,1,1],
    [1,1,1,1,1,2,2,2,1,7,7,7,7,7,1,2,2,2,1,1,1,1,1],
    [1,1,1,1,1,2,1,2,1,7,7,7,7,7,1,2,1,2,1,1,1,1,1],
    [1,1,1,1,1,2,1,2,1,1,1,1,1,1,1,2,1,2,1,1,1,1,1],
    [1,1,1,1,1,2,1,2,2,2,2,2,2,2,2,2,1,2,1,1,1,1,1],
    [1,1,1,1,1,2,1,1,1,1,2,1,2,1,1,1,1,2,1,1,1,1,1],
    [1,2,2,2,2,2,1,2,2,2,2,1,2,2,2,2,1,2,2,2,2,2,1],
    [1,2,1,1,1,2,1,2,1,1,1,1,1,1,1,2,1,2,1,1,1,2,1],
    [1,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,1],
    [1,2,1,1,1,2,1,1,1,1,2,1,2,1,1,1,1,2,1,1,1,2,1],
    [1,2,1,1,1,2,1,1,1,1,2,1,2,1,1,1,1,2,1,1,1,2,1],
    [1,3,2,2,2,2,2,2,2,2,2,1,2,2,2,2,2,2,2,2,2,3,1],
    [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1]
  ]
};

// Objeto especial obligatorio por nivel
const SPECIAL_ITEM_BY_LEVEL = {
  1: 'Computadora',
  2: 'Guardapolvo',
  3: 'Cuaderno',
  4: 'Computadora',
  5: 'Guardapolvo'
};

class PacmanGame {
  constructor(roomCode, playersList) {
    this.roomCode = roomCode;
    this.playersList = playersList; // Lista de configuración de sockets
    this.level = 1;
    this.score = 0;
    this.lives = 3; // Vidas compartidas
    this.state = 'playing'; // 'playing', 'level_clear', 'game_over', 'victory'
    
    this.frightenedTimer = 0;
    this.frightenedCount = 0;
    this.fruit = null; // {type, x, y, duration}
    this.fruitTimer = 0;
    this.specialItemCollected = false; // Si se recogió el objeto especial del nivel
    
    this.loadLevel(this.level, true); // true = primer inicio (reinicia score/vidas)
  }

  // Cargar o reiniciar nivel
  loadLevel(levelNum, resetGame = false) {
    this.level = levelNum;
    
    if (resetGame) {
      this.score = 0;
      this.lives = 3;
    }
    
    this.state = 'playing';
    this.specialItemCollected = false; // Resetear para nuevo nivel
    
    // Copiar mapa original
    const rawMap = MAPS[levelNum] || MAPS[1];
    this.map = rawMap.map(row => [...row]);
    
    this.rows = this.map.length;
    this.cols = this.map[0].length;

    // Encontrar puntos de spawn válidos
    const spawnPoints = [];
    const ghostSpawnPoints = [];

    for (let r = 0; r < this.rows; r++) {
      for (let c = 0; c < this.cols; c++) {
        if (this.map[r][c] === 7) {
          ghostSpawnPoints.push({ x: c, y: r });
        } else if (this.map[r][c] === 2 || this.map[r][c] === 0) {
          spawnPoints.push({ x: c, y: r });
        }
      }
    }

    const ghostSpawns = ghostSpawnPoints.length > 0 ? ghostSpawnPoints : [{ x: Math.floor(this.cols/2), y: Math.floor(this.rows/2) }];
    const playerSpawns = spawnPoints.filter(p => Math.abs(p.x - this.cols/2) > 2);

    // Inicializar jugadores
    this.players = this.playersList.map((p, idx) => {
      const spawn = playerSpawns[idx % playerSpawns.length] || { x: 1, y: 1 };
      return {
        socketId: p.socketId,
        name: p.name,
        character: p.character,
        playerIndex: p.playerIndex,
        x: spawn.x,
        y: spawn.y,
        targetX: spawn.x,
        targetY: spawn.y,
        dir: 'NONE',
        nextDir: 'NONE',
        lastHorizontalDir: 'RIGHT',
        speed: 0.12 + (levelNum * 0.01),
        isDead: false,
        respawnTimer: 0,
        hasGuardapolvo: false
      };
    });

    // Inicializar fantasmas (Lorena, Scaglione, Esteban)
    const ghostNames = ['Lorena', 'Scaglione', 'Esteban'];
    this.ghosts = ghostNames.map((name, idx) => {
      const spawn = ghostSpawns[idx % ghostSpawns.length] || ghostSpawns[0];
      return {
        name,
        x: spawn.x,
        y: spawn.y,
        targetX: spawn.x,
        targetY: spawn.y,
        dir: 'NONE',
        speed: 0.08 + (levelNum * 0.01) + (idx * 0.005),
        mode: 'chase',
        spawnX: spawn.x,
        spawnY: spawn.y,
        respawnTimer: 0
      };
    });

    this.frightenedTimer = 0;
    this.frightenedCount = 0;
    
    // Spawnear objeto especial OBLIGATORIO del nivel
    this.spawnSpecialItem();
    
    this.fruitTimer = Math.floor(Math.random() * 600) + 400; // Timer para objetos bonus (no obligatorios)
  }

  // Spawnear el objeto especial obligatorio del nivel
  spawnSpecialItem() {
    const requiredType = SPECIAL_ITEM_BY_LEVEL[this.level] || 'Cuaderno';
    const walkables = [];
    for (let r = 0; r < this.rows; r++) {
      for (let c = 0; c < this.cols; c++) {
        if (this.map[r][c] === 0) { // Solo en espacios vacíos para no tapar puntos
          walkables.push({ x: c, y: r });
        }
      }
    }
    if (walkables.length > 0) {
      const pos = walkables[Math.floor(Math.random() * walkables.length)];
      this.fruit = { // Reutilizamos fruit para el objeto especial obligatorio
        type: requiredType,
        x: pos.x,
        y: pos.y,
        duration: Infinity, // No se va hasta ser recogido
        isRequired: true
      };
    }
  }

  // Manejar inputs del cliente
  handleInput(socketId, dir) {
    const player = this.players.find(p => p.socketId === socketId);
    if (player && !player.isDead && this.state === 'playing') {
      player.nextDir = dir;
    }
  }

  // Verificar pared
  isWall(x, y) {
    const r = Math.round(y);
    const c = Math.round(x);
    if (r < 0 || r >= this.rows || c < 0 || c >= this.cols) return true;
    return this.map[r][c] === 1;
  }

  // Obtener coordenadas vecinas
  getNeighborCoords(x, y, dir) {
    let nx = x, ny = y;
    if (dir === 'UP') ny--;
    else if (dir === 'DOWN') ny++;
    else if (dir === 'LEFT') nx--;
    else if (dir === 'RIGHT') nx++;
    return { x: nx, y: ny };
  }

  // Actualizar posición de entidad
  updateEntityPosition(entity, isGhost = false) {
    if (entity.isDead || entity.respawnTimer > 0) {
      if (entity.respawnTimer > 0) {
        entity.respawnTimer--;
        if (entity.respawnTimer === 0) {
          entity.x = entity.spawnX || 1;
          entity.y = entity.spawnY || 1;
          entity.targetX = entity.x;
          entity.targetY = entity.y;
          entity.isDead = false;
          if (isGhost) entity.mode = 'chase';
        }
      }
      return;
    }

    const dist = entity.speed;
    const dx = entity.targetX - entity.x;
    const dy = entity.targetY - entity.y;

    if (Math.abs(dx) <= dist && Math.abs(dy) <= dist) {
      entity.x = entity.targetX;
      entity.y = entity.targetY;

      if (!isGhost) {
        if (entity.nextDir !== 'NONE') {
          const check = this.getNeighborCoords(entity.x, entity.y, entity.nextDir);
          if (!this.isWall(check.x, check.y)) {
            entity.dir = entity.nextDir;
          }
        }

        const next = this.getNeighborCoords(entity.x, entity.y, entity.dir);
        if (!this.isWall(next.x, next.y) && entity.dir !== 'NONE') {
          entity.targetX = next.x;
          entity.targetY = next.y;
        } else {
          entity.dir = 'NONE';
        }
      } else {
        this.updateGhostAI(entity);
      }
    } else {
      if (dx !== 0) entity.x += Math.sign(dx) * dist;
      if (dy !== 0) entity.y += Math.sign(dy) * dist;
    }
  }

  // IA de fantasmas
  updateGhostAI(ghost) {
    const directions = ['UP', 'DOWN', 'LEFT', 'RIGHT'];
    const validMoves = [];
    let oppositeDir = 'NONE';
    if (ghost.dir === 'UP') oppositeDir = 'DOWN';
    else if (ghost.dir === 'DOWN') oppositeDir = 'UP';
    else if (ghost.dir === 'LEFT') oppositeDir = 'RIGHT';
    else if (ghost.dir === 'RIGHT') oppositeDir = 'LEFT';

    directions.forEach(d => {
      if (d === oppositeDir) return;
      const coords = this.getNeighborCoords(ghost.x, ghost.y, d);
      if (!this.isWall(coords.x, coords.y)) validMoves.push({ dir: d, x: coords.x, y: coords.y });
    });

    if (validMoves.length === 0 && oppositeDir !== 'NONE') {
      const coords = this.getNeighborCoords(ghost.x, ghost.y, oppositeDir);
      if (!this.isWall(coords.x, coords.y)) validMoves.push({ dir: oppositeDir, x: coords.x, y: coords.y });
    }
    if (validMoves.length === 0) return;

    let chosenMove = null;
    if (ghost.mode === 'frightened') {
      chosenMove = validMoves[Math.floor(Math.random() * validMoves.length)];
    } else {
      let targetX = 1, targetY = 1;
      const activePlayers = this.players.filter(p => !p.isDead);
      const targetPlayer = activePlayers[0] || this.players[0];

      if (ghost.name === 'Lorena') {
        if (targetPlayer) { targetX = targetPlayer.x; targetY = targetPlayer.y; }
      } else if (ghost.name === 'Scaglione') {
        if (Math.random() < 0.3) {
          chosenMove = validMoves[Math.floor(Math.random() * validMoves.length)];
        } else {
          targetX = (this.cols - 2) * (Math.sin(Date.now() / 10000) > 0 ? 1 : 0);
          targetY = (this.rows - 2) * (Math.cos(Date.now() / 10000) > 0 ? 1 : 0);
        }
      } else if (ghost.name === 'Esteban') {
        if (targetPlayer) {
          const ahead = this.getNeighborCoords(targetPlayer.x, targetPlayer.y, targetPlayer.dir);
          targetX = ahead.x; targetY = ahead.y;
        }
      }

      if (!chosenMove) {
        let minDist = Infinity;
        validMoves.forEach(move => {
          const dist = Math.pow(move.x - targetX, 2) + Math.pow(move.y - targetY, 2);
          if (dist < minDist) { minDist = dist; chosenMove = move; }
        });
      }
    }

    if (chosenMove) {
      ghost.dir = chosenMove.dir;
      ghost.targetX = chosenMove.x;
      ghost.targetY = chosenMove.y;
    }
  }

  // Tick del juego
  tick() {
    if (this.state !== 'playing') return;

    // Actualizar entidades
    this.players.forEach(p => this.updateEntityPosition(p, false));
    this.ghosts.forEach(g => this.updateEntityPosition(g, true));

    // Consumir puntos y objetos
    this.players.forEach(p => {
      if (p.isDead) return;
      
      if (p.dir === 'LEFT') p.lastHorizontalDir = 'LEFT';
      if (p.dir === 'RIGHT') p.lastHorizontalDir = 'RIGHT';
      
      const px = Math.round(p.x);
      const py = Math.round(p.y);

      if (px >= 0 && px < this.cols && py >= 0 && py < this.rows) {
        const cell = this.map[py][px];
        if (cell === 2) {
          this.map[py][px] = 0;
          this.score += 10;
          p.score += 10;
        } else if (cell === 3) {
          this.map[py][px] = 0;
          this.score += 50;
          p.score += 50;
          this.activateHoraLibre();
        }
      }

      // Consumir fruta/objeto
      if (this.fruit && Math.round(p.x) === this.fruit.x && Math.round(p.y) === this.fruit.y) {
        if (this.fruit.isRequired) {
          // Objeto especial obligatorio
          this.specialItemCollected = true;
        }
        if (this.fruit.type === 'Guardapolvo') {
          p.hasGuardapolvo = true;
        }
        
        let pts = 100;
        if (this.fruit.type === 'Computadora') pts = 500;
        else if (this.fruit.type === 'Cuaderno') pts = 250;
        
        this.score += pts;
        p.score += pts;
        
        if (!this.fruit.isRequired) {
          this.fruit = null;
        } else {
          // Objeto obligatorio se marca como recogido pero no se elimina visualmente de inmediato?
          // No, lo eliminamos pero sabemos que ya fue recogido
          this.fruit = null;
        }
      }
    });

    // Timer de Hora Libre
    if (this.frightenedTimer > 0) {
      this.frightenedTimer--;
      if (this.frightenedTimer === 0) {
        this.ghosts.forEach(g => { if (g.mode === 'frightened') g.mode = 'chase'; });
      }
    }

    // Spawnear objetos bonus (no obligatorios) solo si NO hay objeto obligatorio pendiente o ya fue recogido
    if (!this.fruit || !this.fruit.isRequired) {
      if (this.fruit && !this.fruit.isRequired) {
        this.fruit.duration--;
        if (this.fruit.duration <= 0) this.fruit = null;
      } else if (!this.fruit && this.specialItemCollected) {
        // Solo spawn bonus si ya tenemos el obligatorio
        this.fruitTimer--;
        if (this.fruitTimer <= 0) {
          const walkables = [];
          for (let r = 0; r < this.rows; r++) {
            for (let c = 0; c < this.cols; c++) {
              if (this.map[r][c] === 0) walkables.push({ x: c, y: r });
            }
          }
          if (walkables.length > 0) {
            const pos = walkables[Math.floor(Math.random() * walkables.length)];
            const types = ['Guardapolvo', 'Cuaderno', 'Computadora'].filter(t => t !== SPECIAL_ITEM_BY_LEVEL[this.level]);
            const randType = types[Math.floor(Math.random() * types.length)] || 'Cuaderno';
            this.fruit = { type: randType, x: pos.x, y: pos.y, duration: 300, isRequired: false };
          }
          this.fruitTimer = Math.floor(Math.random() * 600) + 400;
        }
      }
    }

    this.checkCollisions();
    this.checkLevelCompletion();
  }

  // Activar Hora Libre
  activateHoraLibre() {
    this.frightenedTimer = 300;
    this.frightenedCount = 0;
    this.ghosts.forEach(g => {
      if (g.mode !== 'eaten' && g.mode !== 'dead') {
        g.mode = 'frightened';
        let oppositeDir = 'NONE';
        if (g.dir === 'UP') oppositeDir = 'DOWN';
        else if (g.dir === 'DOWN') oppositeDir = 'UP';
        else if (g.dir === 'LEFT') oppositeDir = 'RIGHT';
        else if (g.dir === 'RIGHT') oppositeDir = 'LEFT';
        const coords = this.getNeighborCoords(g.x, g.y, oppositeDir);
        if (!this.isWall(coords.x, coords.y)) {
          g.dir = oppositeDir;
          g.targetX = coords.x;
          g.targetY = coords.y;
        }
      }
    });
  }

  // Verificar colisiones
  checkCollisions() {
    this.players.forEach(p => {
      if (p.isDead) return;
      this.ghosts.forEach(g => {
        if (g.isDead || g.respawnTimer > 0) return;
        const dist = Math.sqrt(Math.pow(p.x - g.x, 2) + Math.pow(p.y - g.y, 2));
        if (dist < 0.6) {
          if (g.mode === 'frightened') {
            g.isDead = true;
            g.respawnTimer = 150;
            g.mode = 'eaten';
            g.x = g.spawnX;
            g.y = g.spawnY;
            g.targetX = g.spawnX;
            g.targetY = g.spawnY;
            this.frightenedCount = Math.min(this.frightenedCount + 1, 4);
            const pts = 100 * Math.pow(2, this.frightenedCount);
            this.score += pts;
            p.score += pts;
          } else {
            p.isDead = true;
            p.respawnTimer = 90;
            this.lives--;
            if (this.lives <= 0) {
              this.state = 'game_over';
            }
          }
        }
      });
    });
  }

  // Contar puntos restantes
  countRemainingPoints() {
    let count = 0;
    for (let r = 0; r < this.rows; r++) {
      for (let c = 0; c < this.cols; c++) {
        if (this.map[r][c] === 2 || this.map[r][c] === 3) count++;
      }
    }
    return count;
  }

  // Verificar si se completó el nivel
  checkLevelCompletion() {
    const remainingPoints = this.countRemainingPoints();
    const hasAllPoints = remainingPoints === 0;
    
    if (hasAllPoints && this.specialItemCollected) {
      // Nivel completado!
      if (this.level < 5) {
        this.state = 'level_clear';
        setTimeout(() => {
          if (this.state === 'level_clear') {
            this.loadLevel(this.level + 1, false);
          }
        }, 3000);
      } else {
        this.state = 'victory';
      }
    }
  }

  // Retornar estado serializable
  getSerializedState() {
    const remainingPoints = this.countRemainingPoints();
    const requiredItem = SPECIAL_ITEM_BY_LEVEL[this.level] || 'Cuaderno';
    
    // Determinar mensaje de estado
    let levelMessage = '';
    if (this.state === 'level_clear') {
      levelMessage = 'Nivel completado.';
    } else if (remainingPoints > 0 && !this.specialItemCollected) {
      levelMessage = 'Faltan puntos por recoger y debes obtener el objeto especial.';
    } else if (remainingPoints > 0) {
      levelMessage = 'Faltan puntos por recoger.';
    } else if (!this.specialItemCollected) {
      levelMessage = 'Debes obtener el objeto especial.';
    }
    
    return {
      level: this.level,
      score: this.score,
      lives: this.lives,
      state: this.state,
      map: this.map,
      fruit: this.fruit,
      frightened: this.frightenedTimer > 0,
      frightenedTimer: this.frightenedTimer,
      specialItemCollected: this.specialItemCollected,
      specialItemRequired: requiredItem,
      remainingPoints: remainingPoints,
      levelMessage: levelMessage,
      players: this.players.map(p => ({
        name: p.name,
        character: p.character,
        playerIndex: p.playerIndex,
        x: p.x,
        y: p.y,
        dir: p.dir,
        lastHorizontalDir: p.lastHorizontalDir,
        score: p.score,
        isDead: p.isDead,
        hasGuardapolvo: p.hasGuardapolvo
      })),
      ghosts: this.ghosts.map(g => ({
        name: g.name,
        x: g.x,
        y: g.y,
        dir: g.dir,
        mode: g.mode
      }))
    };
  }
}

module.exports = PacmanGame;
