// Controlador del Cliente de Escape Escolar (Pac-Man) - Soporta Local (1P/2P) y Online (Sockets)
document.addEventListener('DOMContentLoaded', () => {
  initClient();
});

let canvas, ctx;
let socketConn = null;
let gameConfig = null;
let localGameInstance = null;
let localIntervalId = null;
let lastState = null;
let rafId = null;
let gamePaused = false;
let _rafLastTime = 0;
let _rafAccumulator = 0;
const TICK_MS = 1000 / 60;
let touchStartX = 0;
let touchStartY = 0;

// Objeto especial por nivel (mismo que en servidor)
const SPECIAL_ITEM_BY_LEVEL = {
  1: 'Computadora',
  2: 'Guardapolvo',
  3: 'Cuaderno',
  4: 'Computadora',
  5: 'Guardapolvo'
};

function initClient() {
  canvas = document.getElementById('gameCanvas');
  ctx = canvas.getContext('2d');

  resizeCanvas();
  window.addEventListener('resize', resizeCanvas);

  const configStr = sessionStorage.getItem('gameConfig');
  if (!configStr) {
    window.location.href = '/';
    return;
  }
  gameConfig = JSON.parse(configStr);

  if (gameConfig.mode === '2P' && gameConfig.multiplayer === 'local') {
    document.getElementById('p2ControlInfo').style.display = 'inline';
  }

  setupKeyboardInput();
  setupTouchInput();

  if (gameConfig.multiplayer === 'online') {
    socketConn = io();
    socketConn.emit('joinRoom', {
      code: gameConfig.roomCode,
      name: gameConfig.players[gameConfig.myIndex].name,
      character: gameConfig.players[gameConfig.myIndex].character
    });
    socketConn.on('gameState', (state) => {
      handleStateUpdate(state);
    });
    socketConn.on('gameOver', ({ gameState }) => {
      handleStateUpdate(gameState);
    });
    document.getElementById('btnOverlayAction').textContent = 'Volver al Lobby';
    document.getElementById('btnOverlayAction').onclick = () => {
      window.location.href = '/lobby';
    };
  } else {
    setupLocalGame();
  }
}

function resizeCanvas() {
  if (!canvas) return;
  const mapData = localGameInstance ? localGameInstance.map : null;
  const rows = mapData ? mapData.length : 1;
  const cols = mapData ? mapData[0].length : 1;
  const aspect = cols / rows;
  const maxW = Math.min(window.innerWidth - 20, 1100);
  const maxH = Math.min(window.innerHeight - 180, 1100);
  let w, h;
  if (maxW / aspect <= maxH) {
    w = maxW;
    h = Math.round(maxW / aspect);
  } else {
    h = maxH;
    w = Math.round(maxH * aspect);
  }
  canvas.width = w;
  canvas.height = h;
  if (lastState) drawPacmanGame(canvas, ctx, lastState);
}

function setupLocalGame() {
  if (rafId) { cancelAnimationFrame(rafId); rafId = null; }
  gamePaused = false;
  _rafLastTime = 0;
  _rafAccumulator = 0;
  document.getElementById('pauseBadge').style.display = 'none';
  document.getElementById('btnPause').textContent = '⏸ Pausa';

  const playersList = [
    { socketId: 'local_p1', name: gameConfig.p1Name, character: gameConfig.p1Character, playerIndex: 0 }
  ];

  if (gameConfig.mode === '2P') {
    const p2Char = gameConfig.p1Character === 'Sara' ? 'Male' : 'Sara';
    playersList.push({ socketId: 'local_p2', name: 'Jugador 2', character: p2Char, playerIndex: 1 });
  }

  localGameInstance = new LocalPacmanEngine(playersList);
  resizeCanvas();
  window.audioSynth && window.audioSynth.startBGM('normal');

  let lastLevel = 1;
  let lastGameState = 'playing';
  let _coinCooldown = 0;

  function gameLoop(timestamp) {
    if (!localGameInstance) return;
    if (_rafLastTime === 0) _rafLastTime = timestamp;
    const dt = Math.min(timestamp - _rafLastTime, 80);
    _rafLastTime = timestamp;

    if (!gamePaused) {
      _rafAccumulator += dt;
      while (_rafAccumulator >= TICK_MS) {
        localGameInstance.tick();
        _rafAccumulator -= TICK_MS;
      }
    }

    const state = localGameInstance.getSerializedState();

    if (state.level !== lastLevel) {
      lastLevel = state.level;
      if (state.level >= 3) {
        window.audioSynth && window.audioSynth.playDangerAlert();
        window.audioSynth && window.audioSynth.switchBGM('danger');
      } else {
        window.audioSynth && window.audioSynth.playLevelUp();
      }
      resizeCanvas();
    }

    if (lastState && !gamePaused) {
      if (_coinCooldown > 0) _coinCooldown -= dt;
      if (state.score > lastState.score && _coinCooldown <= 0) {
        window.audioSynth && window.audioSynth.playCoin();
        _coinCooldown = 85;
      }
      if (!lastState.frightened && state.frightened) {
        window.audioSynth && window.audioSynth.playPowerup();
      }
      const prevEaten = lastState.ghosts.filter(g => g.mode === 'eaten').length;
      const nowEaten = state.ghosts.filter(g => g.mode === 'eaten').length;
      if (nowEaten > prevEaten) window.audioSynth && window.audioSynth.playEatGhost();
      if (state.lives < lastState.lives && state.lives > 0) {
        window.audioSynth && window.audioSynth.playCrash();
      }
    }

    lastState = state;
    document.getElementById('hudLevel').textContent = state.level;
    document.getElementById('hudScore').textContent = state.score;
    document.getElementById('hudLives').textContent = '❤️'.repeat(Math.max(0, state.lives));

    // Mostrar mensaje de estado del nivel
    const levelStatusEl = document.getElementById('levelStatus');
    if (state.levelMessage) {
      levelStatusEl.textContent = state.levelMessage;
      levelStatusEl.style.display = 'block';
    } else {
      levelStatusEl.style.display = 'none';
    }

    drawPacmanGame(canvas, ctx, state);

    if (state.state !== lastGameState) {
      lastGameState = state.state;
      if (state.state === 'game_over') {
        window.audioSynth && window.audioSynth.stopBGM();
        window.audioSynth && window.audioSynth.playGameOver();
        _showOverlay('GAME OVER', '¡Los directivos te atraparon!', state.score, 'text-danger');
        saveLocalScore(state);
        return;
      }
      if (state.state === 'victory') {
        window.audioSynth && window.audioSynth.stopBGM();
        window.audioSynth && window.audioSynth.playVictory();
        const lead = state.players[0];
        const msg = lead.character === 'Sara' ? '🏆 ¡Sara completó todas las materias!' : '🏆 ¡Male escapó de la escuela!';
        _showOverlay('¡VICTORIA!', msg, state.score, 'text-success');
        saveLocalScore(state);
        return;
      }
    }

    rafId = requestAnimationFrame(gameLoop);
  }

  rafId = requestAnimationFrame(gameLoop);

  const actionBtn = document.getElementById('btnOverlayAction');
  actionBtn.textContent = 'Volver a Jugar';
  actionBtn.onclick = () => {
    document.getElementById('gameOverlay').classList.remove('active');
    setupLocalGame();
  };
}

function _showOverlay(title, msg, score, titleClass) {
  const overlay = document.getElementById('gameOverlay');
  const titleEl = document.getElementById('overlayTitle');
  const msgEl = document.getElementById('overlayMessage');
  const scoreSec = document.getElementById('overlayScoreSection');
  const finalScore = document.getElementById('overlayFinalScore');

  titleEl.textContent = title;
  titleEl.className = `display-5 animate-pulse ${titleClass}`;
  msgEl.textContent = msg;
  scoreSec.style.display = 'block';
  finalScore.textContent = score;
  overlay.classList.add('active');
}

function togglePause() {
  if (!localGameInstance) return;
  const state = localGameInstance.getSerializedState();
  if (state.state !== 'playing' && state.state !== 'level_clear') return;

  gamePaused = !gamePaused;
  const badge = document.getElementById('pauseBadge');
  const btn = document.getElementById('btnPause');

  if (gamePaused) {
    badge.style.display = 'flex';
    btn.textContent = '▶ Reanudar';
    window.audioSynth && window.audioSynth.stopBGM();
    window.audioSynth && window.audioSynth.playSelect();
  } else {
    badge.style.display = 'none';
    btn.textContent = '⏸ Pausa';
    _rafLastTime = 0;
    const level = localGameInstance ? localGameInstance.level : 1;
    window.audioSynth && window.audioSynth.startBGM(level >= 3 ? 'danger' : 'normal');
  }
}

function restartGame() {
  if (localGameInstance) {
    localGameInstance.loadLevel(localGameInstance.level, true);
    gamePaused = false;
    document.getElementById('pauseBadge').style.display = 'none';
    document.getElementById('btnPause').textContent = '⏸ Pausa';
  }
}

function saveLocalScore(state) {
  fetch('/api/leaderboard/pacman', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      name: state.players[0].name,
      score: state.score,
      character: state.players[0].character,
      duration: 0,
      victories: state.state === 'victory' ? 1 : 0
    })
  }).catch(err => console.error('Error al guardar puntaje local:', err));
}

function handleStateUpdate(state) {
  if (lastState) {
    if (state.score > lastState.score) {
      window.audioSynth && window.audioSynth.playCoin();
    }
    if (!lastState.frightened && state.frightened) {
      window.audioSynth && window.audioSynth.playPowerup();
    }
    const prevEaten = lastState.ghosts.filter(g => g.mode === 'eaten').length;
    const nowEaten = state.ghosts.filter(g => g.mode === 'eaten').length;
    if (nowEaten > prevEaten) window.audioSynth && window.audioSynth.playEatGhost();
    if (state.lives < lastState.lives && state.lives > 0) {
      window.audioSynth && window.audioSynth.playCrash();
    }
  }

  lastState = state;
  document.getElementById('hudLevel').textContent = state.level;
  document.getElementById('hudScore').textContent = state.score;
  document.getElementById('hudLives').textContent = '❤️'.repeat(Math.max(0, state.lives));

  // Mostrar mensaje de estado del nivel
  const levelStatusEl = document.getElementById('levelStatus');
  if (state.levelMessage) {
    levelStatusEl.textContent = state.levelMessage;
    levelStatusEl.style.display = 'block';
  } else {
    levelStatusEl.style.display = 'none';
  }

  drawPacmanGame(canvas, ctx, state);

  if (state.state === 'game_over') {
    _showOverlay('GAME OVER', '¡Los directivos te atraparon!', state.score, 'text-danger');
    window.audioSynth && window.audioSynth.playGameOver();
  } else if (state.state === 'victory') {
    const lp = state.players[0];
    const msg = lp.character === 'Sara' ? '🏆 ¡Sara completó todas las materias!' : '🏆 ¡Male escapó de la escuela!';
    _showOverlay('¡VICTORIA!', msg, state.score, 'text-success');
    window.audioSynth && window.audioSynth.playVictory();
  }
}

function setupKeyboardInput() {
  window.addEventListener('keydown', (e) => {
    const key = e.key.toUpperCase();
    if (e.key === 'Escape') { e.preventDefault(); togglePause(); return; }
    if (key === 'P') { e.preventDefault(); togglePause(); return; }
    let p1Dir = null;
    if (key === 'W') p1Dir = 'UP';
    else if (key === 'S') p1Dir = 'DOWN';
    else if (key === 'A') p1Dir = 'LEFT';
    else if (key === 'D') p1Dir = 'RIGHT';
    if (p1Dir) { e.preventDefault(); sendMove(0, p1Dir); }

    let arrowDir = null;
    if (key === 'ARROWUP') arrowDir = 'UP';
    else if (key === 'ARROWDOWN') arrowDir = 'DOWN';
    else if (key === 'ARROWLEFT') arrowDir = 'LEFT';
    else if (key === 'ARROWRIGHT') arrowDir = 'RIGHT';
    if (arrowDir) {
      e.preventDefault();
      const idx = (gameConfig && gameConfig.mode === '2P') ? 1 : 0;
      sendMove(idx, arrowDir);
    }
  });
}

function sendMove(playerIdx, direction) {
  if (gameConfig.multiplayer === 'online') {
    if (playerIdx === gameConfig.myIndex) {
      socketConn.emit('playerMove', direction);
    }
  } else {
    if (localGameInstance) {
      const socketId = playerIdx === 0 ? 'local_p1' : 'local_p2';
      localGameInstance.handleInput(socketId, direction);
    }
  }
}

function setupTouchInput() {
  const btnUp = document.getElementById('tBtnUp');
  const btnDown = document.getElementById('tBtnDown');
  const btnLeft = document.getElementById('tBtnLeft');
  const btnRight = document.getElementById('tBtnRight');

  const handleTouch = (dir) => {
    const idx = gameConfig.multiplayer === 'online' ? gameConfig.myIndex : 0;
    sendMove(idx, dir);
  };

  const addButtonEvents = (btn, dir) => {
    btn.addEventListener('touchstart', (e) => { e.preventDefault(); handleTouch(dir); btn.style.transform = 'scale(0.95)'; });
    btn.addEventListener('touchend', (e) => { e.preventDefault(); btn.style.transform = 'scale(1)'; });
    btn.addEventListener('mousedown', (e) => { e.preventDefault(); handleTouch(dir); btn.style.transform = 'scale(0.95)'; });
    btn.addEventListener('mouseup', (e) => { e.preventDefault(); btn.style.transform = 'scale(1)'; });
    btn.addEventListener('mouseleave', (e) => { e.preventDefault(); btn.style.transform = 'scale(1)'; });
  };

  addButtonEvents(btnUp, 'UP');
  addButtonEvents(btnDown, 'DOWN');
  addButtonEvents(btnLeft, 'LEFT');
  addButtonEvents(btnRight, 'RIGHT');

  window.addEventListener('touchstart', (e) => {
    touchStartX = e.changedTouches[0].screenX;
    touchStartY = e.changedTouches[0].screenY;
  }, { passive: true });

  window.addEventListener('touchend', (e) => {
    const diffX = e.changedTouches[0].screenX - touchStartX;
    const diffY = e.changedTouches[0].screenY - touchStartY;
    if (Math.abs(diffX) > Math.abs(diffY)) {
      if (Math.abs(diffX) > 40) {
        handleTouch(diffX > 0 ? 'RIGHT' : 'LEFT');
      }
    } else {
      if (Math.abs(diffY) > 40) {
        handleTouch(diffY > 0 ? 'DOWN' : 'UP');
      }
    }
  }, { passive: true });
}

class LocalPacmanEngine {
  constructor(playersList) {
    this.playersList = playersList;
    this.level = 1;
    this.score = 0;
    this.lives = 3;
    this.state = 'playing';
    this.frightenedTimer = 0;
    this.frightenedCount = 0;
    this.fruit = null;
    this.fruitTimer = 0;
    this.specialItemCollected = false;
    this.loadLevel(this.level, true);
  }

  loadLevel(levelNum, resetGame = false) {
    this.level = levelNum;
    if (resetGame) {
      this.score = 0;
      this.lives = 3;
    }
    this.state = 'playing';
    this.specialItemCollected = false;
    const rawMap = MAPS[levelNum] || MAPS[1];
    this.map = rawMap.map(row => [...row]);
    this.rows = this.map.length;
    this.cols = this.map[0].length;

    const spawnPoints = [];
    const ghostSpawnPoints = [];
    for (let r = 0; r < this.rows; r++) {
      for (let c = 0; c < this.cols; c++) {
        if (this.map[r][c] === 7) ghostSpawnPoints.push({ x: c, y: r });
        else if (this.map[r][c] === 2 || this.map[r][c] === 0) spawnPoints.push({ x: c, y: r });
      }
    }
    const ghostSpawns = ghostSpawnPoints.length > 0 ? ghostSpawnPoints : [{ x: Math.floor(this.cols/2), y: Math.floor(this.rows/2) }];
    const playerSpawns = spawnPoints.filter(p => Math.abs(p.x - this.cols/2) > 2);

    this.players = this.playersList.map((p, idx) => {
      const spawn = playerSpawns[idx % playerSpawns.length] || { x:1, y:1 };
      return {
        socketId: p.socketId, name: p.name, character: p.character, playerIndex: p.playerIndex,
        x: spawn.x, y: spawn.y, targetX: spawn.x, targetY: spawn.y,
        dir: 'NONE', nextDir: 'NONE', lastHorizontalDir: 'RIGHT',
        speed: 0.06 + (levelNum * 0.005),
        isDead: false, respawnTimer: 0, hasGuardapolvo: false
      };
    });

    const ghostNames = ['Lorena', 'Scaglione', 'Esteban'];
    const isHardMode = levelNum >= 3;
    const ghostBaseSpeed = isHardMode ? 0.03 + (levelNum * 0.0225) : 0.04 + (levelNum * 0.005);
    this.ghosts = ghostNames.map((name, idx) => {
      const spawn = ghostSpawns[idx % ghostSpawns.length] || ghostSpawns[0];
      return {
        name, x: spawn.x, y: spawn.y, targetX: spawn.x, targetY: spawn.y, dir: 'NONE',
        speed: ghostBaseSpeed + (idx * (isHardMode ? 0.0075 : 0.0025)),
        mode: 'chase', spawnX: spawn.x, spawnY: spawn.y, respawnTimer:0,
        baseRespawn: isHardMode ? 80 : 300
      };
    });

    this.frightenedTimer =0;
    this.frightenedCount =0;
    this.spawnSpecialItem();
    this.fruitTimer = Math.floor(Math.random()*800)+400;
  }

  spawnSpecialItem() {
    const requiredType = SPECIAL_ITEM_BY_LEVEL[this.level] || 'Cuaderno';
    const walkables = [];
    for (let r =0; r < this.rows; r++) {
      for (let c=0; c < this.cols; c++) {
        if (this.map[r][c] === 0) walkables.push({ x:c, y:r });
      }
    }
    if (walkables.length>0) {
      const pos = walkables[Math.floor(Math.random()*walkables.length)];
      this.fruit = { type: requiredType, x: pos.x, y: pos.y, duration: Infinity, isRequired: true };
    }
  }

  handleInput(socketId, dir) {
    const player = this.players.find(p => p.socketId === socketId);
    if (player && !player.isDead && this.state === 'playing') {
      player.nextDir = dir;
    }
  }

  isWall(x, y) {
    const r = Math.round(y);
    const c = Math.round(x);
    if (r <0 || r >= this.rows || c <0 || c >= this.cols) return true;
    return this.map[r][c] ===1;
  }

  getNeighborCoords(x, y, dir) {
    let nx=x, ny=y;
    if (dir === 'UP') ny--;
    else if (dir === 'DOWN') ny++;
    else if (dir === 'LEFT') nx--;
    else if (dir === 'RIGHT') nx++;
    return { x:nx, y:ny };
  }

  updateEntityPosition(entity, isGhost=false) {
    if (entity.isDead || entity.respawnTimer >0) {
      if (entity.respawnTimer>0) {
        entity.respawnTimer--;
        if (entity.respawnTimer ===0) {
          entity.x = entity.spawnX ||1;
          entity.y = entity.spawnY ||1;
          entity.targetX = entity.x;
          entity.targetY = entity.y;
          entity.isDead = false;
          if (isGhost) entity.mode = 'chase';
        }
      }
      return;
    }
    const dist = entity.speed;
    const dx = entity.targetX - entity.x;
    const dy = entity.targetY - entity.y;
    if (Math.abs(dx) <= dist && Math.abs(dy) <= dist) {
      entity.x = entity.targetX;
      entity.y = entity.targetY;
      if (!isGhost) {
        if (entity.nextDir !== 'NONE') {
          const check = this.getNeighborCoords(entity.x, entity.y, entity.nextDir);
          if (!this.isWall(check.x, check.y)) entity.dir = entity.nextDir;
        }
        const next = this.getNeighborCoords(entity.x, entity.y, entity.dir);
        if (!this.isWall(next.x, next.y) && entity.dir !== 'NONE') {
          entity.targetX = next.x;
          entity.targetY = next.y;
        } else {
          entity.dir = 'NONE';
        }
      } else {
        this.updateGhostAI(entity);
      }
    } else {
      if (dx!==0) entity.x += Math.sign(dx)*dist;
      if (dy!==0) entity.y += Math.sign(dy)*dist;
    }
  }

  updateGhostAI(ghost) {
    const directions = ['UP','DOWN','LEFT','RIGHT'];
    const validMoves = [];
    const isHardMode = this.level >=3;
    let oppositeDir = 'NONE';
    if (ghost.dir === 'UP') oppositeDir = 'DOWN';
    else if (ghost.dir === 'DOWN') oppositeDir = 'UP';
    else if (ghost.dir === 'LEFT') oppositeDir = 'RIGHT';
    else if (ghost.dir === 'RIGHT') oppositeDir = 'LEFT';

    directions.forEach(d => {
      if (d === oppositeDir) return;
      const coords = this.getNeighborCoords(ghost.x, ghost.y, d);
      if (!this.isWall(coords.x, coords.y)) validMoves.push({ dir:d, x:coords.x, y:coords.y });
    });
    if (validMoves.length ===0 && oppositeDir !== 'NONE') {
      const coords = this.getNeighborCoords(ghost.x, ghost.y, oppositeDir);
      if (!this.isWall(coords.x, coords.y)) validMoves.push({ dir:oppositeDir, x:coords.x, y:coords.y });
    }
    if (validMoves.length ===0) return;
    let chosenMove = null;
    if (ghost.mode === 'frightened') {
      if (isHardMode && Math.random() < 0.5) {
        // perseguir
      } else {
        chosenMove = validMoves[Math.floor(Math.random()*validMoves.length)];
      }
    }
    if (!chosenMove) {
      let targetX=1, targetY=1;
      const activePlayers = this.players.filter(p => !p.isDead);
      const targetPlayer = activePlayers[0] || this.players[0];
      if (ghost.name === 'Lorena') {
        if (targetPlayer) { targetX = targetPlayer.x; targetY = targetPlayer.y; }
      } else if (ghost.name === 'Scaglione') {
        const randomChance = isHardMode ? 0.05 : 0.3;
        if (Math.random() < randomChance) {
          chosenMove = validMoves[Math.floor(Math.random()*validMoves.length)];
        } else if (targetPlayer) {
          targetX = targetPlayer.x + (isHardMode?2:0);
          targetY = targetPlayer.y + (isHardMode?2:0);
        }
      } else if (ghost.name === 'Esteban') {
        if (targetPlayer) {
          if (isHardMode) {
            let nx = targetPlayer.x;
            let ny = targetPlayer.y;
            for (let i=0; i<3; i++) {
              const ahead = this.getNeighborCoords(nx, ny, targetPlayer.dir);
              if (!this.isWall(ahead.x, ahead.y)) { nx = ahead.x; ny = ahead.y; }
            }
            targetX = nx; targetY = ny;
          } else {
            const ahead = this.getNeighborCoords(targetPlayer.x, targetPlayer.y, targetPlayer.dir);
            targetX = ahead.x; targetY = ahead.y;
          }
        }
      }
      if (!chosenMove) {
        let minDist = Infinity;
        validMoves.forEach(move => {
          const dist = Math.pow(move.x - targetX, 2) + Math.pow(move.y - targetY,2);
          if (dist < minDist) { minDist = dist; chosenMove = move; }
        });
      }
    }
    if (chosenMove) {
      ghost.dir = chosenMove.dir;
      ghost.targetX = chosenMove.x;
      ghost.targetY = chosenMove.y;
    }
  }

  tick() {
    if (this.state !== 'playing') return;
    this.players.forEach(p => this.updateEntityPosition(p, false));
    this.ghosts.forEach(g => this.updateEntityPosition(g, true));

    this.players.forEach(p => {
      if (p.isDead) return;
      if (p.dir === 'LEFT') p.lastHorizontalDir = 'LEFT';
      if (p.dir === 'RIGHT') p.lastHorizontalDir = 'RIGHT';
      const px = Math.round(p.x);
      const py = Math.round(p.y);
      if (px >=0 && px < this.cols && py >=0 && py < this.rows) {
        const cell = this.map[py][px];
        if (cell ===2) {
          this.map[py][px] = 0;
          this.score +=10;
          p.score = (p.score || 0) +10;
        } else if (cell ===3) {
          this.map[py][px] =0;
          this.score +=50;
          p.score = (p.score ||0)+50;
          this.activateHoraLibre();
        }
      }
      if (this.fruit && Math.round(p.x) === this.fruit.x && Math.round(p.y) === this.fruit.y) {
        if (this.fruit.isRequired) this.specialItemCollected = true;
        if (this.fruit.type === 'Guardapolvo') p.hasGuardapolvo = true;
        let pts = 100;
        if (this.fruit.type === 'Computadora') pts =500;
        else if (this.fruit.type === 'Cuaderno') pts=250;
        this.score += pts;
        p.score = (p.score || 0) + pts;
        if (!this.fruit.isRequired) this.fruit = null;
        else this.fruit = null;
      }
    });

    if (this.frightenedTimer>0) {
      this.frightenedTimer--;
      if (this.frightenedTimer ===0) this.ghosts.forEach(g => { if (g.mode === 'frightened') g.mode = 'chase'; });
    }

    if (!this.fruit || !this.fruit.isRequired) {
      if (this.fruit && !this.fruit.isRequired) {
        this.fruit.duration--;
        if (this.fruit.duration <=0) this.fruit = null;
      } else if (!this.fruit && this.specialItemCollected) {
        this.fruitTimer--;
        if (this.fruitTimer <=0) {
          const walkables = [];
          for (let r=0; r < this.rows; r++) {
            for (let c=0; c < this.cols; c++) {
              if (this.map[r][c] ===0) walkables.push({ x:c, y:r });
            }
          }
          if (walkables.length>0) {
            const pos = walkables[Math.floor(Math.random()*walkables.length)];
            const types = ['Guardapolvo','Cuaderno','Computadora'].filter(t => t !== (SPECIAL_ITEM_BY_LEVEL[this.level] || 'Cuaderno'));
            const randType = types[Math.floor(Math.random()*types.length)] || 'Cuaderno';
            this.fruit = { type: randType, x: pos.x, y: pos.y, duration: 300, isRequired: false };
          }
          this.fruitTimer = Math.floor(Math.random()*1200)+800;
        }
      }
    }

    this.checkCollisions();
    this.checkLevelCompletion();
  }

  activateHoraLibre() {
    this.frightenedTimer = this.level >=3 ? 120 : 600;
    this.frightenedCount=0;
    this.ghosts.forEach(g => {
      if (g.mode !== 'eaten' && g.mode !== 'dead') {
        g.mode = 'frightened';
        let oppositeDir = 'NONE';
        if (g.dir === 'UP') oppositeDir = 'DOWN';
        else if (g.dir === 'DOWN') oppositeDir = 'UP';
        else if (g.dir === 'LEFT') oppositeDir = 'RIGHT';
        else if (g.dir === 'RIGHT') oppositeDir = 'LEFT';
        const coords = this.getNeighborCoords(g.x, g.y, oppositeDir);
        if (!this.isWall(coords.x, coords.y)) {
          g.dir = oppositeDir;
          g.targetX = coords.x;
          g.targetY = coords.y;
        }
      }
    });
  }

  checkCollisions() {
    this.players.forEach(p => {
      if (p.isDead) return;
      this.ghosts.forEach(g => {
        if (g.isDead || g.respawnTimer>0) return;
        const dist = Math.sqrt(Math.pow(p.x - g.x,2) + Math.pow(p.y - g.y,2));
        if (dist <0.6) {
          if (g.mode === 'frightened') {
            g.isDead = true;
            g.respawnTimer = g.baseRespawn || 300;
            g.mode = 'eaten';
            g.x = g.spawnX;
            g.y = g.spawnY;
            g.targetX = g.spawnX;
            g.targetY = g.spawnY;
            this.frightenedCount = Math.min(this.frightenedCount+1,4);
            const pts = 100*Math.pow(2, this.frightenedCount);
            this.score += pts;
            p.score = (p.score ||0) + pts;
          } else {
            p.isDead = true;
            p.respawnTimer =180;
            this.lives--;
            if (this.lives <=0) this.state = 'game_over';
          }
        }
      });
    });
  }

  countRemainingPoints() {
    let count =0;
    for (let r=0; r < this.rows; r++) {
      for (let c=0; c < this.cols; c++) {
        if (this.map[r][c] ===2 || this.map[r][c] ===3) count++;
      }
    }
    return count;
  }

  checkLevelCompletion() {
    const remainingPoints = this.countRemainingPoints();
    const hasAllPoints = remainingPoints ===0;
    if (hasAllPoints && this.specialItemCollected) {
      if (this.level < Object.keys(MAPS).length) {
        this.state = 'level_clear';
        setTimeout(() => {
          if (this.state === 'level_clear') this.loadLevel(this.level+1, false);
        },3000);
      } else {
        this.state = 'victory';
      }
    }
  }

  getSerializedState() {
    const remainingPoints = this.countRemainingPoints();
    const requiredItem = SPECIAL_ITEM_BY_LEVEL[this.level] || 'Cuaderno';
    let levelMessage = '';
    if (this.state === 'level_clear') levelMessage = 'Nivel completado.';
    else if (remainingPoints>0 && !this.specialItemCollected) levelMessage = 'Faltan puntos por recoger y debes obtener el objeto especial.';
    else if (remainingPoints>0) levelMessage = 'Faltan puntos por recoger.';
    else if (!this.specialItemCollected) levelMessage = 'Debes obtener el objeto especial.';
    return {
      level: this.level, score: this.score, lives: this.lives, state: this.state,
      map: this.map, fruit: this.fruit,
      frightened: this.frightenedTimer>0, frightenedTimer: this.frightenedTimer,
      specialItemCollected: this.specialItemCollected,
      specialItemRequired: requiredItem,
      remainingPoints: remainingPoints,
      levelMessage: levelMessage,
      players: this.players.map(p => ({
        name: p.name, character: p.character, playerIndex: p.playerIndex,
        x: p.x, y: p.y, dir: p.dir, lastHorizontalDir: p.lastHorizontalDir,
        score: p.score ||0, isDead: p.isDead, hasGuardapolvo: p.hasGuardapolvo
      })),
      ghosts: this.ghosts.map(g => ({ name: g.name, x:g.x, y:g.y, dir:g.dir, mode:g.mode }))
    };
  }
}

const MAPS = {
  1: [
    [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1],
    [1,3,2,2,2,2,2,1,2,2,2,2,2,3,1],
    [1,2,1,1,2,1,2,1,2,1,2,1,1,2,1],
    [1,2,1,1,2,1,2,2,2,1,2,1,1,2,1],
    [1,2,2,2,2,2,2,1,2,2,2,2,2,2,1],
    [1,2,1,1,2,1,1,1,1,1,2,1,1,2,1],
    [1,2,2,2,2,2,2,7,2,2,2,2,2,2,1],
    [1,1,1,2,1,1,7,7,7,1,1,2,1,1,1],
    [1,2,2,2,2,2,2,7,2,2,2,2,2,2,1],
    [1,2,1,1,2,1,1,1,1,1,2,1,1,2,1],
    [1,2,2,2,2,2,2,1,2,2,2,2,2,2,1],
    [1,2,1,1,2,1,2,2,2,1,2,1,1,2,1],
    [1,2,1,1,2,1,2,1,2,1,2,1,1,2,1],
    [1,3,2,2,2,2,2,1,2,2,2,2,2,3,1],
    [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1]
  ],
  2: [
    [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1],
    [1,3,2,2,2,2,1,1,1,1,1,2,2,2,2,3,1],
    [1,2,1,1,1,2,2,2,1,2,2,2,1,1,1,2,1],
    [1,2,1,1,1,1,1,2,1,2,1,1,1,1,1,2,1],
    [1,2,2,2,1,2,2,2,2,2,2,2,1,2,2,2,1],
    [1,1,1,2,1,2,1,1,7,1,1,2,1,2,1,1,1],
    [1,1,1,2,2,2,1,7,7,7,1,2,2,2,1,1,1],
    [1,1,1,2,1,2,1,1,1,1,1,2,1,2,1,1,1],
    [1,2,2,2,1,2,2,2,2,2,2,2,1,2,2,2,1],
    [1,2,1,1,1,1,1,2,1,2,1,1,1,1,1,2,1],
    [1,2,1,1,1,2,2,2,1,2,2,2,1,1,1,2,1],
    [1,3,2,2,2,2,1,1,1,1,1,2,2,2,2,3,1],
    [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1]
  ],
  3: [
    [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1],
    [1,3,2,2,2,2,2,2,2,1,2,2,2,2,2,2,2,3,1],
    [1,2,1,1,2,1,1,1,2,1,2,1,1,1,2,1,1,2,1],
    [1,2,1,1,2,1,1,1,2,1,2,1,1,1,2,1,1,2,1],
    [1,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,1],
    [1,2,1,1,2,1,2,1,1,1,1,1,2,1,2,1,1,2,1],
    [1,2,2,2,2,1,2,2,2,1,2,2,2,1,2,2,2,2,1],
    [1,1,1,1,2,1,1,1,2,1,2,1,1,1,2,1,1,1,1],
    [1,1,1,1,2,1,7,7,7,7,7,7,7,1,2,1,1,1,1],
    [1,1,1,1,2,1,7,1,1,7,1,1,7,1,2,1,1,1,1],
    [1,1,1,1,2,1,7,7,7,7,7,7,7,1,2,1,1,1,1],
    [1,1,1,1,2,1,1,1,2,1,2,1,1,1,2,1,1,1,1],
    [1,2,2,2,2,1,2,2,2,1,2,2,2,1,2,2,2,2,1],
    [1,2,1,1,2,1,2,1,1,1,1,1,2,1,2,1,1,2,1],
    [1,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,1],
    [1,2,1,1,2,1,1,1,2,1,2,1,1,1,2,1,1,2,1],
    [1,2,1,1,2,1,1,1,2,1,2,1,1,1,2,1,1,2,1],
    [1,3,2,2,2,2,2,2,2,1,2,2,2,2,2,2,2,3,1],
    [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1]
  ],
  4: [
    [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1],
    [1,3,2,2,2,2,2,2,2,2,1,2,2,2,2,2,2,2,2,3,1],
    [1,2,1,1,1,2,1,1,1,2,1,2,1,1,1,2,1,1,1,2,1],
    [1,2,1,1,1,2,1,1,1,2,1,2,1,1,1,2,1,1,1,2,1],
    [1,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,1],
    [1,2,1,1,1,2,1,2,1,1,1,1,1,2,1,2,1,1,1,2,1],
    [1,2,2,2,2,2,1,2,2,2,1,2,2,2,1,2,2,2,2,2,1],
    [1,1,1,1,1,2,1,1,1,2,1,2,1,1,1,2,1,1,1,1,1],
    [1,1,1,1,1,2,1,7,7,7,7,7,7,7,1,2,1,1,1,1,1],
    [1,1,1,1,1,2,1,7,1,1,1,1,1,7,1,2,1,1,1,1,1],
    [1,2,2,2,2,2,2,7,1,1,1,1,1,7,2,2,2,2,2,2,1],
    [1,1,1,1,1,2,1,7,1,1,1,1,1,7,1,2,1,1,1,1,1],
    [1,1,1,1,1,2,1,7,7,7,7,7,7,7,1,2,1,1,1,1,1],
    [1,1,1,1,1,2,1,1,1,2,1,2,1,1,1,2,1,1,1,1,1],
    [1,2,2,2,2,2,1,2,2,2,1,2,2,2,1,2,2,2,2,2,1],
    [1,2,1,1,1,2,1,2,1,1,1,1,1,2,1,2,1,1,1,2,1],
    [1,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,1],
    [1,2,1,1,1,2,1,1,1,2,1,2,1,1,1,2,1,1,1,2,1],
    [1,2,1,1,1,2,1,1,1,2,1,2,1,1,1,2,1,1,1,2,1],
    [1,3,2,2,2,2,2,2,2,2,1,2,2,2,2,2,2,2,2,3,1],
    [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1]
  ],
  5: [
    [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1],
    [1,3,2,2,2,2,2,2,2,2,2,1,2,2,2,2,2,2,2,2,2,3,1],
    [1,2,1,1,1,2,1,1,1,1,2,1,2,1,1,1,1,2,1,1,1,2,1],
    [1,2,1,1,1,2,1,1,1,1,2,1,2,1,1,1,1,2,1,1,1,2,1],
    [1,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,1],
    [1,2,1,1,1,2,1,2,1,1,1,1,1,1,1,2,1,2,1,1,1,2,1],
    [1,2,2,2,2,2,1,2,2,2,2,1,2,2,2,2,1,2,2,2,2,2,1],
    [1,1,1,1,1,2,1,1,1,1,2,1,2,1,1,1,1,2,1,1,1,1,1],
    [1,1,1,1,1,2,1,2,2,2,2,2,2,2,2,2,1,2,1,1,1,1,1],
    [1,1,1,1,1,2,1,2,1,1,1,7,1,1,1,2,1,2,1,1,1,1,1],
    [1,1,1,1,1,2,2,2,1,7,7,7,7,7,1,2,2,2,1,1,1,1,1],
    [1,1,1,1,1,2,1,2,1,7,7,7,7,7,1,2,1,2,1,1,1,1,1],
    [1,1,1,1,1,2,1,2,1,1,1,1,1,1,1,2,1,2,1,1,1,1,1],
    [1,1,1,1,1,2,1,2,2,2,2,2,2,2,2,2,1,2,1,1,1,1,1],
    [1,1,1,1,1,2,1,1,1,1,2,1,2,1,1,1,1,2,1,1,1,1,1],
    [1,2,2,2,2,2,1,2,2,2,2,1,2,2,2,2,1,2,2,2,2,2,1],
    [1,2,1,1,1,2,1,2,1,1,1,1,1,1,1,2,1,2,1,1,1,2,1],
    [1,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,1],
    [1,2,1,1,1,2,1,1,1,1,2,1,2,1,1,1,1,2,1,1,1,2,1],
    [1,2,1,1,1,2,1,1,1,1,2,1,2,1,1,1,1,2,1,1,1,2,1],
    [1,3,2,2,2,2,2,2,2,2,2,1,2,2,2,2,2,2,2,2,2,3,1],
    [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1]
  ]
};
